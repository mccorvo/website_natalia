from __future__ import annotations

import json
from html import escape
from pathlib import Path
from urllib.parse import quote


ROOT = Path(__file__).resolve().parents[1]
ARTICLES_DIR = ROOT / "articles"
ASSETS = "assets/images/"

EMAIL = "Dietolozki@gmail.com"
INSTAGRAM = "https://www.instagram.com/natural.healing.dublin?igsh=MXYxMmticzFsam10eg%3D%3D"
FACEBOOK = "https://www.facebook.com/people/Natural-Healing/61572266563392/?mibextid=wwXIfr&rdid=RKUIF0cw8DOPcoCm&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1GhXD36Qzc%2F%3Fmibextid%3DwwXIfr%26ref%3D1"
TODAY = "2026-04-25"


def span(pl: str, en: str) -> str:
    return f'<span class="lang-pl-content">{escape(pl)}</span><span class="lang-en-content">{escape(en)}</span>'


def attr(value: str) -> str:
    return escape(value, quote=True)


ARTICLES = [
    {
        "slug": "zdrowe-odzywianie-bez-restrykcji",
        "category_pl": "Podstawy",
        "category_en": "Basics",
        "minutes": "6 min",
        "title_pl": "Jak zacząć zdrowe odżywianie bez restrykcyjnej diety",
        "title_en": "How to start eating healthier without a restrictive diet",
        "desc_pl": "Prosty, spokojny sposób na lepsze jedzenie bez liczenia wszystkiego i bez podejścia wszystko albo nic.",
        "desc_en": "A calm, practical way to improve eating without tracking everything or falling into all-or-nothing thinking.",
        "sections_pl": [
            ("Zacznij od rytmu, nie od zakazów", "Zdrowsze odżywianie najczęściej zaczyna się od powtarzalnego rytmu: śniadania lub pierwszego pełnego posiłku, sensownej przerwy między posiłkami i wieczoru bez nadrabiania całego dnia. Zamiast usuwać połowę produktów, sprawdź, kiedy jesz i czy posiłki dają sytość."),
            ("Zbuduj talerz z trzech elementów", "W praktyce pomocny jest prosty schemat: warzywa lub owoce, źródło białka oraz produkt węglowodanowy dobrej jakości albo zdrowy tłuszcz. Taki talerz łatwiej dopasować do pracy, rodziny i budżetu niż sztywny jadłospis."),
            ("Wybierz jedną zmianę na tydzień", "Jedna zmiana wykonana konsekwentnie działa lepiej niż pięć ambitnych zasad porzuconych po dwóch dniach. Może to być dodatkowa porcja warzyw, przygotowanie lunchu do pracy albo zamiana słodkiego napoju na wodę przez większość dni."),
            ("Obserwuj, nie oceniaj", "Notuj energię, sytość, trawienie i zachcianki bez moralizowania. Jedzenie nie jest testem charakteru. To informacja o potrzebach ciała, planie dnia i tym, czy posiłki były wystarczające."),
        ],
        "sections_en": [
            ("Start with rhythm, not bans", "Healthier eating usually begins with a repeatable rhythm: breakfast or a first complete meal, reasonable spacing between meals and an evening that does not compensate for the entire day. Instead of removing half your foods, notice when you eat and whether your meals keep you satisfied."),
            ("Build a plate from three elements", "A practical structure is simple: vegetables or fruit, a source of protein and a quality carbohydrate or healthy fat. This is easier to adapt to work, family and budget than a rigid meal plan."),
            ("Choose one change per week", "One change done consistently works better than five ambitious rules abandoned after two days. It can be an extra portion of vegetables, preparing lunch for work or replacing sweet drinks with water most days."),
            ("Observe without judging", "Track energy, fullness, digestion and cravings without moralising. Food is not a character test. It is information about your body, your day and whether your meals were enough."),
        ],
    },
    {
        "slug": "insulinoopornosc-dieta-nawyki",
        "category_pl": "Metabolizm",
        "category_en": "Metabolism",
        "minutes": "7 min",
        "title_pl": "Insulinooporność: co warto wiedzieć o diecie i codziennych nawykach",
        "title_en": "Insulin resistance: what to know about diet and daily habits",
        "desc_pl": "Jak wspierać stabilniejszą energię i glikemię bez skrajnych diet i strachu przed węglowodanami.",
        "desc_en": "How to support steadier energy and glucose without extreme diets or fear of carbohydrates.",
        "sections_pl": [
            ("Insulinooporność nie wymaga paniki", "Rozpoznanie insulinooporności nie oznacza automatycznie diety bez węglowodanów. U wielu osób ważniejsze są jakość posiłków, regularność, aktywność, sen i dopasowanie porcji do realnego zapotrzebowania."),
            ("Łącz węglowodany z białkiem i błonnikiem", "Owsianka z jogurtem i owocami, kasza z rybą i warzywami albo kanapki z pełnoziarnistego pieczywa z jajkiem i sałatą zwykle wspierają sytość lepiej niż samotna słodka przekąska. Kontekst posiłku ma znaczenie."),
            ("Ruch po jedzeniu może pomóc", "Krótki spacer po większym posiłku bywa bardziej realny niż idealny plan treningowy. Mięśnie zużywają glukozę, więc regularny ruch, nawet spokojny, jest ważnym elementem codziennego wsparcia."),
            ("Nie zmieniaj leczenia samodzielnie", "Jeśli masz stan przedcukrzycowy, cukrzycę, PCOS albo przyjmujesz leki wpływające na glikemię, plan żywieniowy powinien być uzgodniony z lekarzem i dopasowany do wyników badań."),
        ],
        "sections_en": [
            ("Insulin resistance does not require panic", "A diagnosis of insulin resistance does not automatically mean a no-carbohydrate diet. For many people, meal quality, consistency, movement, sleep and portion fit matter more."),
            ("Combine carbohydrates with protein and fibre", "Oats with yoghurt and fruit, grains with fish and vegetables or wholegrain sandwiches with egg and salad usually support satiety better than a sweet snack on its own. Meal context matters."),
            ("Movement after meals can help", "A short walk after a larger meal can be more realistic than a perfect training plan. Muscles use glucose, so regular movement, even gentle movement, is a useful daily support."),
            ("Do not change treatment on your own", "If you have prediabetes, diabetes, PCOS or take medication that affects glucose, your nutrition plan should be discussed with your clinician and adapted to your test results."),
        ],
    },
    {
        "slug": "zdrowe-sniadania-proste-pomysly",
        "category_pl": "Praktyka",
        "category_en": "Practical meals",
        "minutes": "5 min",
        "title_pl": "Zdrowe śniadania: proste pomysły na każdy dzień",
        "title_en": "Healthy breakfasts: simple ideas for everyday",
        "desc_pl": "Śniadania, które dają sytość, energię i są możliwe do przygotowania nawet w zabiegany poranek.",
        "desc_en": "Breakfasts that support satiety and energy while still fitting busy mornings.",
        "sections_pl": [
            ("Śniadanie nie musi być idealne", "Najlepsze śniadanie to takie, które jesteś w stanie powtórzyć. Może być bardzo proste: jogurt naturalny, owoce, płatki i orzechy albo pełnoziarnista kanapka z jajkiem i warzywami."),
            ("Dodaj białko", "Białko pomaga utrzymać sytość i ograniczyć podjadanie chwilę po posiłku. W śniadaniu może pochodzić z jajek, jogurtu, twarogu, tofu, ryby, strączków albo dobrej jakości pasty kanapkowej."),
            ("Nie zapominaj o błonniku", "Owoce, warzywa, płatki owsiane, pełnoziarniste pieczywo, nasiona i orzechy wspierają jelita i stabilniejszą energię. To mały element, który często robi dużą różnicę."),
            ("Przygotuj wersję awaryjną", "Warto mieć w domu dwa szybkie zestawy: jeden na słodko i jeden wytrawny. Dzięki temu poranek nie kończy się przypadkową przekąską albo kawą zamiast posiłku."),
        ],
        "sections_en": [
            ("Breakfast does not need to be perfect", "The best breakfast is one you can repeat. It can be simple: natural yoghurt, fruit, oats and nuts, or a wholegrain sandwich with egg and vegetables."),
            ("Add protein", "Protein helps with fullness and can reduce snacking soon after a meal. At breakfast it may come from eggs, yoghurt, cottage cheese, tofu, fish, pulses or a good-quality spread."),
            ("Remember fibre", "Fruit, vegetables, oats, wholegrain bread, seeds and nuts support digestion and steadier energy. This small element often makes a big difference."),
            ("Prepare a backup option", "It helps to have two quick sets at home: one sweet and one savoury. That way a busy morning does not end with a random snack or coffee instead of food."),
        ],
    },
    {
        "slug": "dieta-przeciwzapalna-fakty",
        "category_pl": "Styl życia",
        "category_en": "Lifestyle",
        "minutes": "7 min",
        "title_pl": "Dieta przeciwzapalna: fakty, produkty i praktyczne wskazówki",
        "title_en": "Anti-inflammatory eating: facts, foods and practical tips",
        "desc_pl": "Bez mitu superfoods: liczy się powtarzalny wzorzec jedzenia, różnorodność i codzienne podstawy.",
        "desc_en": "Beyond superfood myths: the repeatable pattern, variety and daily basics matter most.",
        "sections_pl": [
            ("To nie jest jedna lista cudownych produktów", "Przeciwzapalny sposób jedzenia opiera się na całości diety, nie na jednym napoju, proszku czy modnym składniku. Znaczenie mają warzywa, owoce, strączki, pełne ziarna, orzechy, pestki, oliwa i regularne posiłki."),
            ("Ogranicz to, co wypiera podstawy", "Nie chodzi o zakaz wszystkiego słodkiego. Warto jednak zauważyć, kiedy wysoko przetworzone przekąski, alkohol, słodkie napoje albo fast food zaczynają zastępować pełnowartościowe posiłki."),
            ("Zadbaj o tłuszcze dobrej jakości", "Ryby, oliwa, orzechy, pestki i awokado mogą być elementem wspierającego sposobu żywienia. Równie ważne jest to, aby dieta nie była zbyt monotonna i nie opierała się wyłącznie na produktach wysoko przetworzonych."),
            ("Sen i stres też są częścią układanki", "Jedzenie ma znaczenie, ale nie działa w próżni. Przewlekły stres, mało snu i brak ruchu mogą wpływać na samopoczucie tak samo mocno jak talerz."),
        ],
        "sections_en": [
            ("It is not one magic food list", "An anti-inflammatory way of eating is about the whole pattern, not one drink, powder or trendy ingredient. Vegetables, fruit, pulses, wholegrains, nuts, seeds, olive oil and regular meals all matter."),
            ("Limit what pushes the basics out", "This is not about banning every sweet food. It is about noticing when highly processed snacks, alcohol, sweet drinks or fast food start replacing balanced meals."),
            ("Choose quality fats", "Fish, olive oil, nuts, seeds and avocado can be part of a supportive eating pattern. It is just as important that the diet is varied and not based mainly on highly processed foods."),
            ("Sleep and stress are part of the picture", "Food matters, but it does not work in isolation. Chronic stress, short sleep and low movement can affect wellbeing as strongly as what is on the plate."),
        ],
    },
    {
        "slug": "jelita-mikrobiota-trawienie",
        "category_pl": "Jelita",
        "category_en": "Gut health",
        "minutes": "6 min",
        "title_pl": "Jelita i mikrobiota: jak wspierać trawienie na co dzień",
        "title_en": "Gut health and microbiota: how to support digestion every day",
        "desc_pl": "Codzienne podstawy dla jelit: regularność, błonnik, nawodnienie, spokojne jedzenie i obserwacja objawów.",
        "desc_en": "Daily gut basics: rhythm, fibre, hydration, calmer eating and symptom awareness.",
        "sections_pl": [
            ("Różnorodność roślin działa lepiej niż perfekcja", "Warzywa, owoce, strączki, pełne ziarna, orzechy, pestki i zioła dostarczają różnych rodzajów błonnika. Nie trzeba jeść idealnie, ale warto stopniowo zwiększać różnorodność."),
            ("Zwiększaj błonnik powoli", "Nagły skok ilości błonnika może nasilić wzdęcia lub dyskomfort. Bezpieczniej dodawać go etapami i obserwować tolerancję, zwłaszcza jeśli wcześniej dieta była uboga w produkty roślinne."),
            ("Jedz spokojniej, gdy możesz", "Trawienie zaczyna się przed żołądkiem: tempo jedzenia, przeżuwanie i poziom napięcia mają znaczenie. Nawet kilka spokojniejszych posiłków w tygodniu może być dobrym początkiem."),
            ("Objawy przewlekłe warto skonsultować", "Silny ból, krew w stolcu, niezamierzona utrata masy ciała, gorączka albo objawy utrzymujące się długo wymagają kontaktu z lekarzem. Dieta nie powinna zastępować diagnostyki."),
        ],
        "sections_en": [
            ("Plant variety matters more than perfection", "Vegetables, fruit, pulses, wholegrains, nuts, seeds and herbs provide different types of fibre. You do not need to eat perfectly, but gradually increasing variety helps."),
            ("Increase fibre slowly", "A sudden jump in fibre can increase bloating or discomfort. It is safer to add it step by step and observe tolerance, especially if your previous diet was low in plant foods."),
            ("Eat more calmly when you can", "Digestion starts before the stomach: eating pace, chewing and stress level matter. Even a few calmer meals each week can be a good start."),
            ("Persistent symptoms need support", "Severe pain, blood in stool, unplanned weight loss, fever or symptoms that persist should be discussed with a doctor. Diet should not replace diagnosis."),
        ],
    },
    {
        "slug": "odchudzanie-bez-efektu-jojo",
        "category_pl": "Masa ciała",
        "category_en": "Weight management",
        "minutes": "7 min",
        "title_pl": "Odchudzanie bez efektu jo-jo: realistyczne podejście",
        "title_en": "Weight loss without yo-yo dieting: a realistic approach",
        "desc_pl": "Jak myśleć o redukcji masy ciała bez obietnic, restrykcji i powrotu do starych schematów.",
        "desc_en": "How to approach weight management without promises, restriction or returning to old patterns.",
        "sections_pl": [
            ("Tempo powinno pasować do życia", "Bardzo szybkie odchudzanie często wymaga zasad, których nie da się utrzymać. Realistyczne tempo daje przestrzeń na naukę posiłków, zakupów, sytości i reagowania na trudniejsze dni."),
            ("Sytość jest ważna", "Plan redukcji nie powinien oznaczać ciągłego głodu. Pomagają pełne posiłki z białkiem, warzywami, błonnikiem i rozsądną ilością tłuszczu, a nie tylko zmniejszanie porcji bez planu."),
            ("Nie oceniaj postępów jednym dniem", "Masa ciała naturalnie się waha. Sen, cykl menstruacyjny, stres, sól i trening mogą wpływać na wynik z dnia na dzień. Lepiej patrzeć na trend i zachowania, które można powtarzać."),
            ("Utrzymanie zaczyna się w trakcie redukcji", "Jeśli sposób jedzenia działa tylko przez kilka tygodni, efekt jo-jo jest bardziej prawdopodobny. Warto od początku budować rozwiązania, które będą możliwe również po zakończeniu redukcji."),
        ],
        "sections_en": [
            ("The pace should fit your life", "Very fast weight loss often requires rules that are hard to maintain. A realistic pace gives room to learn meals, shopping, fullness and how to respond to harder days."),
            ("Satiety matters", "A weight-management plan should not mean constant hunger. Complete meals with protein, vegetables, fibre and a reasonable amount of fat help more than simply shrinking portions without a plan."),
            ("Do not judge progress by one day", "Body weight naturally fluctuates. Sleep, menstrual cycle, stress, salt and training can influence day-to-day numbers. Trends and repeatable behaviours are more useful."),
            ("Maintenance starts during weight loss", "If an eating pattern only works for a few weeks, rebound is more likely. From the beginning, build solutions that will still be possible after the active weight-loss phase."),
        ],
    },
    {
        "slug": "bialko-w-diecie",
        "category_pl": "Składniki",
        "category_en": "Nutrients",
        "minutes": "6 min",
        "title_pl": "Białko w diecie: ile potrzebujesz i skąd je brać",
        "title_en": "Protein in the diet: how much you need and where to get it",
        "desc_pl": "Praktyczne spojrzenie na białko bez obsesji: sytość, mięśnie, regeneracja i codzienne źródła.",
        "desc_en": "A practical look at protein without obsession: satiety, muscle, recovery and everyday sources.",
        "sections_pl": [
            ("Białko wspiera sytość", "Posiłek z dobrym źródłem białka zwykle syci na dłużej niż posiłek oparty wyłącznie na szybko przyswajalnych węglowodanach. To ważne przy energii, zachciankach i regularności jedzenia."),
            ("Źródła mogą być różne", "Jaja, ryby, mięso, nabiał, tofu, tempeh, strączki, orzechy i nasiona mogą mieć miejsce w diecie. Nie każdy potrzebuje odżywki białkowej; często wystarcza lepsze rozłożenie białka w posiłkach."),
            ("Ilość zależy od osoby", "Zapotrzebowanie zależy od masy ciała, wieku, aktywności, celu, stanu zdrowia i ciąży lub laktacji. Przy chorobach nerek lub innych schorzeniach ilość białka trzeba omówić indywidualnie."),
            ("Rozłóż białko w ciągu dnia", "Dla wielu osób praktycznym krokiem jest dodanie źródła białka do śniadania i lunchu, a nie jedzenie większości dopiero wieczorem. To prosta zmiana, która często poprawia sytość."),
        ],
        "sections_en": [
            ("Protein supports satiety", "A meal with a good protein source usually keeps you fuller than a meal based only on fast-digesting carbohydrates. This matters for energy, cravings and meal rhythm."),
            ("Sources can vary", "Eggs, fish, meat, dairy, tofu, tempeh, pulses, nuts and seeds can all fit. Not everyone needs protein powder; often it is enough to distribute protein better across meals."),
            ("The amount depends on the person", "Needs depend on body size, age, activity, goal, health status and pregnancy or breastfeeding. With kidney disease or other conditions, protein intake should be discussed individually."),
            ("Spread protein through the day", "For many people, adding protein to breakfast and lunch is more useful than eating most of it in the evening. It is a simple change that often improves fullness."),
        ],
    },
    {
        "slug": "dieta-przy-pracy-biurowej",
        "category_pl": "Praca",
        "category_en": "Workday",
        "minutes": "6 min",
        "title_pl": "Dieta przy pracy biurowej: energia, koncentracja i regularność",
        "title_en": "Eating with office work: energy, focus and rhythm",
        "desc_pl": "Jak jeść lepiej przy siedzącej pracy, spotkaniach, kawie zamiast lunchu i spadkach energii.",
        "desc_en": "How to eat better with desk work, meetings, coffee instead of lunch and afternoon energy dips.",
        "sections_pl": [
            ("Zaplanuj minimum, nie ideał", "Przy pracy biurowej często wystarczy ustalić dwa punkty dnia: co zjesz przed największym blokiem pracy i co będzie lunchem. Plan minimum zmniejsza liczbę decyzji podejmowanych w głodzie."),
            ("Lunch powinien dawać stabilność", "Kanapka może być dobrym lunchem, jeśli ma białko, warzywa i sycące dodatki. Sałatka też może być pełnym posiłkiem, jeśli nie składa się tylko z liści."),
            ("Kawa nie zastępuje jedzenia", "Kawa może być przyjemnym rytuałem, ale używana zamiast posiłku często kończy się spadkiem energii i większym głodem po południu. Warto połączyć ją z realnym jedzeniem."),
            ("Ruch w małych porcjach", "Krótkie przerwy od siedzenia, spacer po lunchu albo wyjście po wodę mogą wspierać koncentrację. To nie musi być trening, żeby miało znaczenie dla dnia."),
        ],
        "sections_en": [
            ("Plan the minimum, not the ideal", "With office work, it often helps to set two anchors: what you eat before the biggest work block and what lunch will be. A minimum plan reduces decisions made while hungry."),
            ("Lunch should provide stability", "A sandwich can be a good lunch if it includes protein, vegetables and filling extras. A salad can also be complete if it is not just leaves."),
            ("Coffee does not replace food", "Coffee can be a pleasant ritual, but using it instead of a meal often leads to an energy dip and stronger hunger later. Pair it with actual food."),
            ("Movement in small doses", "Short breaks from sitting, a walk after lunch or getting water can support focus. It does not need to be a workout to matter during the day."),
        ],
    },
    {
        "slug": "slodycze-zachcianki-emocjonalne-jedzenie",
        "category_pl": "Relacja z jedzeniem",
        "category_en": "Food relationship",
        "minutes": "7 min",
        "title_pl": "Słodycze, zachcianki i emocjonalne jedzenie: jak odzyskać kontrolę",
        "title_en": "Sweets, cravings and emotional eating: how to regain control",
        "desc_pl": "Spokojne strategie na zachcianki bez wojny z jedzeniem, poczucia winy i kolejnych restrykcji.",
        "desc_en": "Calm strategies for cravings without fighting food, guilt or another restrictive cycle.",
        "sections_pl": [
            ("Zachcianka nie jest porażką", "Ochota na słodkie może wynikać z głodu, zmęczenia, stresu, nawyku albo zbyt restrykcyjnego podejścia. Zanim ją oceniasz, sprawdź, co wydarzyło się wcześniej w ciągu dnia."),
            ("Najpierw zadbaj o regularne posiłki", "Pomijanie posiłków często zwiększa wieczorne podjadanie. Pełniejsze śniadanie, lunch z białkiem i zaplanowana przekąska mogą zmniejszyć poczucie utraty kontroli."),
            ("Nie buduj atmosfery zakazu", "Im bardziej produkt jest zakazany, tym większą może mieć siłę. U wielu osób lepiej działa świadome włączenie ulubionych słodyczy w rozsądnej ilości niż cykl restrykcji i objadania."),
            ("Szukaj także regulacji emocji", "Jeśli jedzenie jest jedynym sposobem na napięcie, warto budować inne narzędzia: rozmowę, spacer, przerwę, sen, pracę z emocjami. Czasem potrzebne jest wsparcie psychologiczne lub psychodietetyczne."),
        ],
        "sections_en": [
            ("A craving is not failure", "Wanting something sweet can come from hunger, tiredness, stress, habit or an overly restrictive approach. Before judging it, look at what happened earlier in the day."),
            ("Start with regular meals", "Skipping meals often increases evening snacking. A fuller breakfast, a protein-containing lunch and a planned snack can reduce the feeling of losing control."),
            ("Do not create a ban atmosphere", "The more forbidden a food feels, the more power it can gain. For many people, consciously including favourite sweets in a reasonable amount works better than restriction and overeating cycles."),
            ("Look for emotional regulation too", "If food is the only way to manage tension, it helps to build other tools: conversation, walking, pausing, sleep or emotional work. Psychological or psychodietetic support may be useful."),
        ],
    },
    {
        "slug": "planowanie-posilkow-brak-czasu",
        "category_pl": "Organizacja",
        "category_en": "Planning",
        "minutes": "6 min",
        "title_pl": "Planowanie posiłków: jak jeść lepiej, kiedy brakuje czasu",
        "title_en": "Meal planning: how to eat better when time is limited",
        "desc_pl": "Meal prep bez presji: baza produktów, szybkie zestawy i plan awaryjny na trudniejsze tygodnie.",
        "desc_en": "Meal prep without pressure: base ingredients, quick combinations and backup plans for busy weeks.",
        "sections_pl": [
            ("Nie musisz gotować na cały tydzień", "Planowanie posiłków nie musi oznaczać pięciu identycznych pudełek. Często wystarczy przygotować bazę: ugotowaną kaszę, umyte warzywa, źródło białka i sos lub pastę."),
            ("Zbuduj listę szybkich zestawów", "Warto mieć kilka posiłków, które da się zrobić w 10-15 minut: tortilla z hummusem i warzywami, jajka z pieczywem i sałatą, makaron z tuńczykiem i pomidorami albo jogurt z owocami i orzechami."),
            ("Zakupy są częścią planu", "Najlepszy jadłospis nie pomoże, jeśli w domu nie ma składników. Krótka lista podstawowych produktów zmniejsza liczbę decyzji i ułatwia jedzenie lepiej nawet przy zmęczeniu."),
            ("Miej plan awaryjny", "Gotowe zupy, mrożone warzywa, konserwy strączkowe, ryby w puszce czy pełnoziarniste pieczywo mogą uratować dzień. Wygoda nie musi oznaczać rezygnacji ze zdrowia."),
        ],
        "sections_en": [
            ("You do not need to cook for the whole week", "Meal planning does not have to mean five identical boxes. Often it is enough to prepare base elements: cooked grains, washed vegetables, a protein source and a sauce or spread."),
            ("Build a list of quick combinations", "It helps to have a few meals that take 10-15 minutes: a tortilla with hummus and vegetables, eggs with bread and salad, pasta with tuna and tomatoes or yoghurt with fruit and nuts."),
            ("Shopping is part of the plan", "The best menu will not help if the ingredients are not at home. A short list of basic foods reduces decisions and makes eating better easier when tired."),
            ("Keep a backup plan", "Ready soups, frozen vegetables, canned pulses, tinned fish or wholegrain bread can save the day. Convenience does not have to mean giving up on health."),
        ],
    },
]


def professional_schema(prefix: str = "") -> dict:
    return {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Natural Healing - Natalia Wcisło",
        "email": EMAIL,
        "image": f"{prefix}assets/images/natalia-hero.jpg",
        "areaServed": ["Dublin", "Ireland", "Online"],
        "availableLanguage": ["pl", "en"],
        "sameAs": [INSTAGRAM, FACEBOOK],
        "description": "Polish and English nutrition support in Dublin and online.",
    }


def article_schema(article: dict, prefix: str = "../") -> dict:
    return {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": article["title_pl"],
        "alternativeHeadline": article["title_en"],
        "description": article["desc_pl"],
        "datePublished": TODAY,
        "dateModified": TODAY,
        "inLanguage": ["pl", "en"],
        "author": {"@type": "Person", "name": "Natalia Wcisło"},
        "publisher": {"@type": "Organization", "name": "Natural Healing"},
        "image": f"{prefix}assets/images/natalia-hero.jpg",
    }


def book_schema(prefix: str = "") -> dict:
    return {
        "@context": "https://schema.org",
        "@type": "Book",
        "name": "Depresja i jedzenie. Lekcja z Japonii",
        "alternateName": "Depression and Food: A Lesson from Japan",
        "author": {"@type": "Person", "name": "Natalia Wcisło"},
        "publisher": {"@type": "Organization", "name": "Natural Healing"},
        "inLanguage": ["pl", "en"],
        "creativeWorkStatus": "In progress",
        "image": f"{prefix}assets/images/depression-food-japan-cover.png",
        "description": "Zapowiedź książki Natalii Wcisło o jedzeniu, codziennym rytmie i łagodnym wsparciu dobrostanu psychicznego, inspirowana obserwacjami z Japonii.",
    }


def head(
    title_pl: str,
    title_en: str,
    desc_pl: str,
    desc_en: str,
    prefix: str = "",
    schema: list[dict] | None = None,
    og_image_path: str | None = None,
    extra_css: list[str] | None = None,
) -> str:
    og_image = og_image_path or f"{prefix}assets/images/natalia-hero.jpg"
    schema_blocks = ""
    for item in schema or []:
        schema_blocks += f'\n  <script type="application/ld+json">{json.dumps(item, ensure_ascii=False)}</script>'
    extra_css_links = "".join(f'\n  <link rel="stylesheet" href="{prefix}{href}">' for href in extra_css or [])
    return f"""<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title_pl)}</title>
  <meta name="description" content="{attr(desc_pl)}" data-description-pl="{attr(desc_pl)}" data-description-en="{attr(desc_en)}">
  <meta name="robots" content="index, follow">
  <link rel="icon" href="{prefix}assets/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="{prefix}css/styles.css">{extra_css_links}
  <meta property="og:title" content="{attr(title_pl)}" data-og-title-pl="{attr(title_pl)}" data-og-title-en="{attr(title_en)}">
  <meta property="og:description" content="{attr(desc_pl)}" data-og-description-pl="{attr(desc_pl)}" data-og-description-en="{attr(desc_en)}">
  <meta property="og:image" content="{og_image}">
  <meta property="og:type" content="website">
  <meta property="og:locale" content="pl_PL" data-og-locale>
  <meta name="twitter:card" content="summary_large_image">{schema_blocks}
</head>"""


def header(active: str, prefix: str = "") -> str:
    def nav_link(key: str, href: str, pl: str, en: str) -> str:
        current = ' aria-current="page"' if active == key else ""
        return f'<a href="{prefix}{href}"{current}>{span(pl, en)}</a>'

    return f"""
<a class="skip-link" href="#main">{span("Przejdź do treści", "Skip to content")}</a>
<header class="site-header">
  <div class="header-inner">
    <a class="brand" href="{prefix}index.html" aria-label="Natural Healing - Natalia Wcisło">
      <img src="{prefix}assets/logo.svg" alt="" aria-hidden="true">
      <span>Natural Healing<small>Natalia Wcisło</small></span>
    </a>
    <button class="nav-toggle" type="button" aria-controls="site-nav" aria-expanded="false">
      <span class="nav-toggle-mark" aria-hidden="true"><span></span><span></span><span></span></span>
      <span>{span("Menu", "Menu")}</span>
    </button>
    <nav class="nav" id="site-nav" aria-label="Main navigation">
      {nav_link("home", "index.html", "Start", "Home")}
      {nav_link("book", "book.html", "Książka", "Book")}
      {nav_link("blog", "blog.html", "Blog", "Blog")}
      {nav_link("autotest", "autotest.html", "Autotest", "Self-check")}
      {nav_link("contact", "contact.html", "Kontakt", "Contact")}
      <a class="nav-cta" href="{prefix}index.html#booking">{span("Umów wizytę", "Book a visit")}</a>
      <span class="lang-switch" aria-label="Language switcher">
        <button class="lang-btn" type="button" data-set-lang="pl" aria-pressed="true">PL</button>
        <button class="lang-btn" type="button" data-set-lang="en" aria-pressed="false">EN</button>
      </span>
    </nav>
  </div>
</header>"""


def footer(prefix: str = "") -> str:
    return f"""
<footer class="site-footer">
  <div class="container footer-grid">
    <div>
      <div class="footer-brand"><img src="{prefix}assets/logo.svg" alt="" aria-hidden="true"><strong>Natural Healing</strong></div>
      <p>{span("Wsparcie żywieniowe Natalii Wcisło w Dublinie i online. Treści na stronie mają charakter edukacyjny i nie zastępują indywidualnej diagnozy medycznej.", "Nutrition support by Natalia Wcisło in Dublin and online. Website content is educational and does not replace individual medical diagnosis.")}</p>
    </div>
    <div>
      <strong>{span("Strony", "Pages")}</strong>
      <ul class="footer-links">
        <li><a href="{prefix}index.html">{span("Start", "Home")}</a></li>
        <li><a href="{prefix}book.html">{span("Książka", "Book")}</a></li>
        <li><a href="{prefix}blog.html">Blog</a></li>
        <li><a href="{prefix}autotest.html">{span("Autotest", "Self-check")}</a></li>
        <li><a href="{prefix}contact.html">{span("Kontakt", "Contact")}</a></li>
      </ul>
    </div>
    <div>
      <strong>{span("Kontakt", "Contact")}</strong>
      <ul class="footer-links">
        <li><a href="mailto:{EMAIL}">{EMAIL}</a></li>
        <li><a href="{INSTAGRAM}" target="_blank" rel="noopener">Instagram</a></li>
        <li><a href="{FACEBOOK}" target="_blank" rel="noopener">Facebook</a></li>
      </ul>
    </div>
  </div>
  <div class="container footer-bottom">
    <span>© 2026 Natural Healing. Natalia Wcisło.</span>
    <span>{span("Przed publikacją formularza produkcyjnego dodaj politykę prywatności i informacje RODO/GDPR.", "Before publishing a production form, add a privacy policy and GDPR information.")}</span>
  </div>
</footer>"""


def booking_form(form_id: str) -> str:
    return f"""
<form class="form-card" data-booking-form>
  <div class="form-grid">
    <div class="field">
      <label for="{form_id}-name">{span("Imię i nazwisko", "Full name")}</label>
      <input id="{form_id}-name" name="name" autocomplete="name" required>
    </div>
    <div class="field">
      <label for="{form_id}-email">Email</label>
      <input id="{form_id}-email" name="email" type="email" autocomplete="email" required>
    </div>
    <div class="field">
      <label for="{form_id}-phone">{span("Telefon", "Phone")} <span class="optional">{span("opcjonalnie", "optional")}</span></label>
      <input id="{form_id}-phone" name="phone" autocomplete="tel">
    </div>
    <div class="field">
      <label for="{form_id}-preferred-language">{span("Preferowany język", "Preferred language")}</label>
      <select id="{form_id}-preferred-language" name="preferred_language" required>
        <option value="" data-text-pl="Wybierz" data-text-en="Choose">Wybierz</option>
        <option value="Polish" data-text-pl="Polski" data-text-en="Polish">Polski</option>
        <option value="English" data-text-pl="Angielski" data-text-en="English">Angielski</option>
      </select>
    </div>
    <div class="field full">
      <label for="{form_id}-type">{span("Typ konsultacji", "Consultation type")}</label>
      <select id="{form_id}-type" name="type" required>
        <option value="" data-text-pl="Wybierz" data-text-en="Choose">Wybierz</option>
        <option value="First consultation" data-text-pl="Pierwsza konsultacja" data-text-en="First consultation">Pierwsza konsultacja</option>
        <option value="Follow-up consultation" data-text-pl="Konsultacja kontrolna" data-text-en="Follow-up consultation">Konsultacja kontrolna</option>
        <option value="Online consultation" data-text-pl="Konsultacja online" data-text-en="Online consultation">Konsultacja online</option>
        <option value="Question about the book" data-text-pl="Pytanie o książkę i listę oczekujących" data-text-en="Question about the book and waiting list">Pytanie o książkę i listę oczekujących</option>
        <option value="Other" data-text-pl="Inne" data-text-en="Other">Inne</option>
      </select>
    </div>
    <div class="field full">
      <label for="{form_id}-message">{span("Wiadomość", "Message")}</label>
      <textarea id="{form_id}-message" name="message" data-placeholder-pl="Napisz krótko, czego potrzebujesz. Nie wpisuj tu bardzo wrażliwych danych medycznych." data-placeholder-en="Briefly describe what you need. Please do not include highly sensitive medical details here." placeholder="Napisz krótko, czego potrzebujesz. Nie wpisuj tu bardzo wrażliwych danych medycznych." required></textarea>
    </div>
    <div class="field full">
      <label class="checkbox">
        <input type="checkbox" name="consent" required>
        <span>{span("Wyrażam zgodę na kontakt mailowy w celu obsługi mojego zapytania.", "I agree to be contacted by email so my request can be handled.")}</span>
      </label>
    </div>
    <div class="field full form-actions">
      <button class="btn btn-primary" type="submit">{span("Wyślij zapytanie", "Send request")}</button>
      <p class="form-status" data-form-status aria-live="polite"></p>
    </div>
  </div>
</form>"""


def page(
    title_pl: str,
    title_en: str,
    desc_pl: str,
    desc_en: str,
    active: str,
    main: str,
    prefix: str = "",
    schema: list[dict] | None = None,
    og_image_path: str | None = None,
    extra_css: list[str] | None = None,
    extra_js: list[str] | None = None,
) -> str:
    extra_scripts = "".join(f'\n<script src="{prefix}{src}"></script>' for src in extra_js or [])
    return f"""{head(title_pl, title_en, desc_pl, desc_en, prefix, schema, og_image_path, extra_css)}
<body class="lang-pl" data-title-pl="{attr(title_pl)}" data-title-en="{attr(title_en)}">
{header(active, prefix)}
<main id="main">
{main}
</main>
{footer(prefix)}
<script src="{prefix}js/main.js"></script>{extra_scripts}
</body>
</html>
"""


def article_card(article: dict, prefix: str = "") -> str:
    return f"""
<article class="card blog-card">
  <div class="card-kicker"><span>{span(article["category_pl"], article["category_en"])}</span><span>{article["minutes"]}</span></div>
  <h3>{span(article["title_pl"], article["title_en"])}</h3>
  <p>{span(article["desc_pl"], article["desc_en"])}</p>
  <a class="read-more" href="{prefix}articles/{article["slug"]}.html">{span("Czytaj artykuł", "Read article")}</a>
</article>"""


def home_page() -> str:
    featured = "".join(article_card(article) for article in ARTICLES[:3])
    main = f"""
<section class="hero">
  <div class="container hero-inner">
    <div class="hero-copy">
      <span class="eyebrow">{span("Natural Healing w Dublinie", "Natural Healing in Dublin")}</span>
      <h1>{span("Naturalne podejście do zdrowia, odżywiania i codziennych nawyków", "A natural approach to health, nutrition and everyday habits")}</h1>
      <p class="lead">{span("Natalia Wcisło wspiera osoby, które chcą jeść spokojniej, lepiej rozumieć swoje ciało i budować nawyki możliwe do utrzymania w prawdziwym życiu.", "Natalia Wcisło supports people who want calmer eating, a better understanding of their body and habits that can be maintained in real life.")}</p>
      <div class="action-row">
        <a class="btn btn-primary" href="#booking">{span("Umów wizytę", "Book a visit")}</a>
        <a class="btn btn-secondary" href="#intro">{span("Dowiedz się więcej", "Learn more")}</a>
      </div>
      <div class="trust-row" aria-label="Highlights">
        <div><strong>PL / EN</strong><span>{span("konsultacje po polsku i angielsku", "consultations in Polish and English")}</span></div>
        <div><strong>Dublin + online</strong><span>{span("wsparcie lokalnie i zdalnie", "local and remote support")}</span></div>
        <div><strong>{span("Bez diet cud", "No miracle diets")}</strong><span>{span("praktyczne, spokojne kroki", "practical, calm steps")}</span></div>
      </div>
    </div>
    <figure class="hero-portrait">
      <img src="assets/images/natalia-hero-cutout.png" alt="Natalia Wcisło, specjalistka od żywienia w Dublinie" data-alt-pl="Natalia Wcisło, specjalistka od żywienia w Dublinie" data-alt-en="Natalia Wcisło, Polish nutritionist in Dublin">
      <figcaption>{span("Indywidualne wsparcie żywieniowe bez presji perfekcji.", "Individual nutrition support without pressure to be perfect.")}</figcaption>
    </figure>
  </div>
</section>

<section class="section" id="intro">
  <div class="container split">
    <div class="media-frame">
      <img src="assets/images/natalia-about.jpg" alt="Natalia Wcisło w gabinecie Natural Healing" data-alt-pl="Natalia Wcisło w gabinecie Natural Healing" data-alt-en="Natalia Wcisło in the Natural Healing practice">
    </div>
    <div class="stack">
      <span class="eyebrow">{span("Poznaj Natalię", "Meet Natalia")}</span>
      <h2>{span("Ciepłe, konkretne wsparcie żywieniowe dla osób, które chcą poczuć większy spokój przy jedzeniu.", "Warm, specific nutrition support for people who want more calm around food.")}</h2>
      <p>{span("Natalia pracuje z osobami, które chcą uporządkować posiłki, poprawić codzienną energię, zadbać o trawienie, relację z jedzeniem lub przygotować plan dopasowany do pracy, rodziny i życia w Dublinie.", "Natalia works with people who want to organise meals, support daily energy, care for digestion, improve their relationship with food or build a plan that fits work, family and life in Dublin.")}</p>
      <p>{span("Podejście jest praktyczne i evidence-informed: bez straszenia jedzeniem, bez obietnic leczenia chorób i bez gotowych schematów dla każdego.", "The approach is practical and evidence-informed: no fear-based food rules, no promises to cure disease and no one-size-fits-all templates.")}</p>
      <div class="mini-list">
        <span>{span("Konsultacje 1:1", "1:1 consultations")}</span>
        <span>{span("Wsparcie online", "Online support")}</span>
        <span>{span("Nawyki i plan posiłków", "Habits and meal planning")}</span>
      </div>
    </div>
  </div>
</section>

<section class="section muted-band">
  <div class="container cta-band">
    <div>
      <span class="eyebrow">{span("Autotest relacji z jedzeniem", "Eating Pattern Self-Check")}</span>
      <h2>{span("Nie jesteś pewna/y, czy Twoja relacja z jedzeniem jest zdrowa?", "Not sure whether your relationship with food feels healthy?")}</h2>
      <p>{span("Zrób krótki, anonimowy autotest. To nie jest diagnoza, ale może pomóc zauważyć sygnały, o których warto porozmawiać ze specjalistą.", "Take a short anonymous self-check. This is not a diagnosis, but it can help you notice signals that may be worth discussing with a professional.")}</p>
    </div>
    <div class="action-row">
      <a class="btn btn-primary" href="autotest.html">{span("Zrób autotest", "Take the self-check")}</a>
      <a class="btn btn-secondary" href="autotest.html#support-resources">{span("Zobacz źródła wsparcia", "View support resources")}</a>
    </div>
  </div>
</section>

<section class="section muted-band">
  <div class="container">
    <div class="section-head">
      <div>
        <span class="eyebrow">{span("Jak wygląda współpraca", "How support works")}</span>
        <h2>{span("Plan, który pasuje do człowieka, nie odwrotnie.", "A plan that fits the person, not the other way around.")}</h2>
      </div>
      <p>{span("Najpierw rozumiemy rytm dnia, zdrowie, preferencje i ograniczenia. Dopiero potem powstają zalecenia, które mają sens poza idealnym tygodniem.", "First we understand your daily rhythm, health, preferences and constraints. Then the guidance can make sense beyond a perfect week.")}</p>
    </div>
    <div class="grid-3">
      <article class="card"><span class="icon-badge">1</span><h3>{span("Spokojna rozmowa", "Calm conversation")}</h3><p>{span("Bez oceniania i bez gotowych założeń. Ważne są objawy, styl życia, historia diet i to, co realnie możesz zmienić.", "No judgement and no fixed assumptions. Symptoms, lifestyle, dieting history and what you can realistically change all matter.")}</p></article>
      <article class="card"><span class="icon-badge">2</span><h3>{span("Praktyczne kroki", "Practical steps")}</h3><p>{span("Zalecenia są konkretne: posiłki, zakupy, zamienniki, rytm dnia i małe decyzje, które można powtarzać.", "Guidance is specific: meals, shopping, swaps, daily rhythm and small decisions you can repeat.")}</p></article>
      <article class="card"><span class="icon-badge">3</span><h3>{span("Edukacja zamiast zakazów", "Education over bans")}</h3><p>{span("Celem jest większa samodzielność, nie zależność od kolejnej restrykcyjnej listy produktów.", "The goal is more independence, not dependence on another restrictive food list.")}</p></article>
    </div>
  </div>
</section>

<section class="section" id="reviews">
  <div class="container">
    <div class="section-head">
      <div>
        <span class="eyebrow">{span("Opinie", "Testimonials")}</span>
        <h2>{span("Miejsce na prawdziwe, zaakceptowane opinie pacjentów.", "A place for real, approved patient testimonials.")}</h2>
      </div>
      <p>{span("Nie publikujemy fikcyjnych historii. Ta sekcja jest przygotowana wizualnie i czeka na zweryfikowane opinie.", "No fictional stories are published. This section is visually prepared and waiting for verified testimonials.")}</p>
    </div>
    <!-- Replace these testimonial placeholders only with real, approved patient testimonials before publication. -->
    <div class="grid-3">
      <article class="card testimonial"><p>{span("Opinie pacjentów zostaną dodane wkrótce.", "Patient testimonials will be added soon.")}</p><strong>{span("Opinia pacjenta", "Patient testimonial")}</strong><span class="placeholder-label">Placeholder</span></article>
      <article class="card testimonial"><p>{span("Tutaj pojawi się krótka, zatwierdzona opinia o współpracy.", "A short, approved review of the collaboration will appear here.")}</p><strong>{span("Konsultacja 1:1", "1:1 consultation")}</strong><span class="placeholder-label">Placeholder</span></article>
      <article class="card testimonial"><p>{span("Ta karta zostanie uzupełniona po otrzymaniu zgody na publikację.", "This card will be completed after publication consent is received.")}</p><strong>{span("Wsparcie żywieniowe", "Nutrition support")}</strong><span class="placeholder-label">Placeholder</span></article>
    </div>
  </div>
</section>

<section class="section book-teaser">
  <div class="container book-panel">
    <img src="assets/images/depression-food-japan-cover.png" alt="Okładka książki Depresja i jedzenie. Lekcja z Japonii Natalii Wcisło" data-alt-pl="Okładka książki Depresja i jedzenie. Lekcja z Japonii Natalii Wcisło" data-alt-en="Cover of Depression and Food: A Lesson from Japan by Natalia Wcisło">
    <div class="stack">
      <span class="eyebrow">{span("Książka Natalii Wcisło • w przygotowaniu", "Natalia Wcisło's book • coming soon")}</span>
      <h2>{span("Depresja i jedzenie. Lekcja z Japonii.", "Depression and Food. A Lesson from Japan.")}</h2>
      <p>{span("Zapowiedź książki o tym, jak codzienny rytm posiłków, kultura jedzenia i łagodne nawyki mogą wspierać dobrostan psychiczny. To materiał edukacyjny, nie obietnica leczenia depresji.", "A forthcoming book about how daily meal rhythm, food culture and gentle habits can support mental wellbeing. It is educational, not a promise to treat depression.")}</p>
      <div class="action-row">
        <a class="btn btn-terra" href="book.html">{span("Zobacz książkę", "View the book")}</a>
        <a class="btn btn-secondary" href="mailto:{EMAIL}?subject=Lista%20oczekuj%C4%85cych%20-%20Depresja%20i%20jedzenie">{span("Dołącz do listy", "Join the list")}</a>
      </div>
    </div>
  </div>
</section>

<section class="section muted-band" id="booking">
  <div class="container split form-split">
    <div class="stack">
      <span class="eyebrow">{span("Rezerwacja", "Booking")}</span>
      <h2>{span("Umów pierwszą konsultację.", "Book your first consultation.")}</h2>
      <p>{span("Formularz przygotuje wiadomość e-mail do Natalii. To praktyczny fallback dla strony statycznej; przed publikacją produkcyjną warto podłączyć bezpieczny system formularzy lub rezerwacji.", "The form prepares an email to Natalia. This is a practical fallback for a static site; before production, connect a secure form or booking system.")}</p>
      <div class="contact-note">
        <strong>Email</strong>
        <a href="mailto:{EMAIL}">{EMAIL}</a>
      </div>
    </div>
    {booking_form("home-booking")}
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-head">
      <div>
        <span class="eyebrow">Blog</span>
        <h2>{span("Czytaj spokojne, praktyczne teksty o odżywianiu.", "Read calm, practical articles about nutrition.")}</h2>
      </div>
      <a class="btn btn-secondary" href="blog.html">{span("Otwórz blog", "Open blog")}</a>
    </div>
    <div class="blog-grid">{featured}</div>
  </div>
</section>
"""
    return page(
        "Natalia Wcisło | Polska specjalistka żywienia w Dublinie",
        "Natalia Wcisło | Polish nutritionist in Dublin",
        "Naturalne, praktyczne wsparcie żywieniowe po polsku i angielsku. Konsultacja dietetyczna online i w Dublinie z Natalią Wcisło.",
        "Natural, practical nutrition support in Polish and English. Online nutrition consultation and Dublin-based support with Natalia Wcisło.",
        "home",
        main,
        schema=[professional_schema()],
    )


def book_page() -> str:
    main = f"""
<section class="page-hero book-hero">
  <div class="container book-layout">
    <div class="book-cover-card">
      <img src="assets/images/depression-food-japan-cover.png" alt="Okładka książki Depresja i jedzenie. Lekcja z Japonii Natalii Wcisło" data-alt-pl="Okładka książki Depresja i jedzenie. Lekcja z Japonii Natalii Wcisło" data-alt-en="Cover of Depression and Food: A Lesson from Japan by Natalia Wcisło">
    </div>
    <div class="stack">
      <span class="eyebrow">{span("Książka • w przygotowaniu", "Book • coming soon")}</span>
      <h1>{span("Depresja i jedzenie. Lekcja z Japonii.", "Depression and Food. A Lesson from Japan.")}</h1>
      <p class="lead">{span("Książka Natalii Wcisło będzie spokojnym, praktycznym przewodnikiem o jedzeniu, nastroju, codziennym rytmie i inspiracjach z japońskiej kultury posiłków.", "Natalia Wcisło's book will be a calm, practical guide to food, mood, daily rhythm and inspiration from Japanese food culture.")}</p>
      <div class="action-row">
        <a class="btn btn-primary" href="mailto:{EMAIL}?subject=Lista%20oczekuj%C4%85cych%20-%20Depresja%20i%20jedzenie">{span("Dołącz do listy oczekujących", "Join the waiting list")}</a>
        <a class="btn btn-secondary" href="index.html#booking">{span("Umów konsultację", "Book a consultation")}</a>
      </div>
      <div class="info-list">
        <div><span>{span("Status", "Status")}</span><strong>{span("Coming soon", "Coming soon")}</strong></div>
        <div><span>{span("Autor", "Author")}</span><strong>Natalia Wcisło</strong></div>
        <div><span>{span("Temat", "Theme")}</span><strong>{span("odżywianie, nastrój, Japonia", "nutrition, mood, Japan")}</strong></div>
      </div>
    </div>
  </div>
</section>

<section class="section muted-band">
  <div class="container grid-3">
    <article class="card"><span class="icon-badge">01</span><h3>{span("O czym będzie", "What it is about")}</h3><p>{span("O tym, jak regularne posiłki, łagodna struktura dnia, sytość i spokojna relacja z jedzeniem mogą wspierać codzienny dobrostan psychiczny.", "How regular meals, a gentle daily structure, satiety and a calmer relationship with food can support everyday mental wellbeing.")}</p></article>
    <article class="card"><span class="icon-badge">02</span><h3>{span("Lekcja z Japonii", "A lesson from Japan")}</h3><p>{span("Inspiracje z prostoty, sezonowości, fermentowanych produktów, rytuału posiłku i uważności przy stole. Bez kopiowania kultury i bez sztywnych zasad.", "Inspiration from simplicity, seasonality, fermented foods, meal rituals and attentiveness at the table. Without copying a culture or creating rigid rules.")}</p></article>
    <article class="card"><span class="icon-badge">03</span><h3>{span("Dla kogo", "Who it is for")}</h3><p>{span("Dla osób, które doświadczają spadków nastroju lub zmęczenia i chcą zacząć od realnych, małych kroków przy jedzeniu. Przy depresji książka nie zastępuje leczenia.", "For people experiencing low mood or tiredness who want to begin with realistic, small steps around food. With depression, the book does not replace treatment.")}</p></article>
  </div>
</section>

<section class="section">
  <div class="container split">
    <div class="stack">
      <span class="eyebrow">{span("Dlaczego Natalia ją pisze", "Why Natalia is writing it")}</span>
      <h2>{span("Bo rozmowa o jedzeniu i nastroju potrzebuje więcej spokoju, a mniej obietnic.", "Because the conversation about food and mood needs more calm and fewer promises.")}</h2>
      <p>{span("Jedzenie nie leczy depresji, ale sposób odżywiania, regularność i codzienne rytuały mogą być jednym z elementów troski o siebie. Natalia chce pokazać ten temat praktycznie, bez straszenia i bez perfekcjonizmu.", "Food does not cure depression, but nutrition, regularity and daily rituals can be one part of self-care. Natalia wants to present the topic practically, without fear-based messaging or perfectionism.")}</p>
    </div>
    <div class="feature-list">
      <div><strong>{span("Czytelnik znajdzie", "Readers will find")}</strong><p>{span("Proste schematy posiłków, przykłady łagodnego planowania, pytania do samoobserwacji i inspiracje z japońskiego podejścia do codziennego jedzenia.", "Simple meal frameworks, gentle planning examples, self-observation questions and inspiration from the Japanese approach to everyday eating.")}</p></div>
      <div><strong>{span("Czego książka nie obiecuje", "What the book does not promise")}</strong><p>{span("Nie diagnozuje, nie zastępuje psychoterapii ani leczenia psychiatrycznego i nie sugeruje odstawiania leków. Ma wspierać edukację i lepsze codzienne wybory.", "It does not diagnose, replace psychotherapy or psychiatric care, or suggest stopping medication. It supports education and better everyday choices.")}</p></div>
      <div><strong>{span("Po lekturze", "After reading")}</strong><p>{span("Można wrócić do bloga, dołączyć do listy oczekujących albo umówić konsultację, jeśli sytuacja wymaga indywidualnego planu żywieniowego.", "Readers can return to the blog, join the waiting list or book a consultation if their situation needs an individual nutrition plan.")}</p></div>
    </div>
  </div>
</section>

<section class="section final-cta">
  <div class="container cta-band">
    <div>
      <span class="eyebrow">{span("Chcesz otrzymać informację o premierze?", "Want to hear when it launches?")}</span>
      <h2>{span("Dołącz do listy oczekujących na książkę.", "Join the waiting list for the book.")}</h2>
    </div>
    <div class="action-row">
      <a class="btn btn-primary" href="mailto:{EMAIL}?subject=Lista%20oczekuj%C4%85cych%20-%20Depresja%20i%20jedzenie">{span("Dołącz do listy", "Join the list")}</a>
      <a class="btn btn-secondary" href="blog.html">{span("Przejdź do bloga", "Go to blog")}</a>
    </div>
  </div>
</section>
"""
    return page(
        "Depresja i jedzenie. Lekcja z Japonii | Natalia Wcisło",
        "Depression and Food: A Lesson from Japan | Natalia Wcisło",
        "Zapowiedź książki Natalii Wcisło o jedzeniu, nastroju i inspiracjach z Japonii. Treści edukacyjne, nie zastępują leczenia depresji.",
        "Coming soon: Natalia Wcisło's book about food, mood and inspiration from Japan. Educational content, not a replacement for depression treatment.",
        "book",
        main,
        schema=[professional_schema(), book_schema()],
        og_image_path="assets/images/depression-food-japan-cover.png",
    )


def autotest_page() -> str:
    subject_pl = "Chciał(a)bym porozmawiać o mojej relacji z jedzeniem"
    subject_en = "I would like to talk about my relationship with food"
    subject_pl_url = quote(subject_pl)
    subject_en_url = quote(subject_en)
    main = f"""
<section class="page-hero self-check-hero">
  <div class="container narrow stack">
    <span class="eyebrow">{span("Autotest", "Self-check")}</span>
    <h1>{span("Autotest relacji z jedzeniem", "Eating Pattern Self-Check")}</h1>
    <p class="lead">{span("Krótka, anonimowa ankieta, która pomaga zauważyć sygnały ryzyka w relacji z jedzeniem, ciałem i kontrolą.", "A short anonymous self-check to help you notice possible risk signals in your relationship with food, body image and control.")}</p>
    <div class="action-row">
      <a class="btn btn-primary" href="#self-check-tool">{span("Rozpocznij autotest", "Start the self-check")}</a>
      <a class="btn btn-secondary" href="#support-resources">{span("Zobacz źródła wsparcia", "View support resources")}</a>
    </div>
  </div>
</section>

<section class="section" id="self-check-start">
  <div class="container self-check-layout">
    <article class="card self-check-notice">
      <span class="eyebrow">{span("Ważne przed startem", "Important before you start")}</span>
      <h2>{span("To narzędzie nie jest diagnozą.", "This tool is not a diagnosis.")}</h2>
      <p>{span("To narzędzie nie jest diagnozą i nie zastępuje konsultacji z lekarzem, psychologiem, psychoterapeutą, psychiatrą ani specjalistą leczenia zaburzeń odżywiania. Wynik pokazuje jedynie obszary, które mogą wymagać rozmowy ze specjalistą.", "This tool is not a diagnosis and does not replace a consultation with a doctor, psychologist, psychotherapist, psychiatrist or eating-disorder specialist. The result only highlights areas that may be worth discussing with a professional.")}</p>
      <p>{span("Ten autotest może pomóc zauważyć wzorce w Twojej relacji z jedzeniem. Tylko wykwalifikowany specjalista medyczny lub zdrowia psychicznego może ocenić sytuację, postawić diagnozę i zalecić leczenie.", "This self-check can help you notice patterns in your relationship with food. Only a qualified medical or mental health professional can assess, diagnose and recommend treatment.")}</p>
      <p>{span("Jeśli martwisz się swoim jedzeniem, obrazem ciała, wymiotami, ograniczaniem jedzenia, objadaniem się lub objawami zdrowotnymi, porozmawiaj z lekarzem rodzinnym, psychologiem, psychiatrą, specjalistą leczenia zaburzeń odżywiania lub innym wykwalifikowanym specjalistą.", "If you are worried about your eating, body image, purging, restriction, binge eating or health symptoms, please speak with a GP, psychologist, psychiatrist, eating-disorder specialist or other qualified professional.")}</p>
      <div class="soft-note">
        <strong>{span("Wiek", "Age")}</strong>
        <p>{span("Jeśli masz mniej niż 18 lat, porozmawiaj z zaufaną osobą dorosłą, rodzicem/opiekunem lub lekarzem.", "If you are under 18, please speak with a trusted adult, parent/guardian or doctor.")}</p>
      </div>
      <div class="urgent-note">
        <strong>{span("Pilne sytuacje", "Urgent situations")}</strong>
        <p>{span("Jeśli masz myśli samobójcze, omdlenia, ból w klatce piersiowej, silne osłabienie, częste wymioty, krwawienie, szybkie pogorszenie stanu zdrowia lub czujesz, że jesteś w bezpośrednim niebezpieczeństwie, skontaktuj się natychmiast z lokalnymi służbami ratunkowymi.", "If you have suicidal thoughts, fainting, chest pain, severe weakness, frequent vomiting, bleeding, rapid health deterioration or feel in immediate danger, contact local emergency services immediately.")}</p>
      </div>
    </article>
    <aside class="card self-check-side">
      <span class="icon-badge">PL/EN</span>
      <h3>{span("Prywatność", "Privacy")}</h3>
      <p>{span("Ankieta działa lokalnie w Twojej przeglądarce. Odpowiedzi nie są zapisywane ani wysyłane.", "This self-check runs locally in your browser. Your answers are not stored or sent.")}</p>
      <p>{span("Nie pytamy o dokładną wagę, BMI, kalorie ani wymiary ciała. Wynik nie zostanie automatycznie dodany do wiadomości e-mail.", "We do not ask for exact weight, BMI, calories or body measurements. Your result is not automatically added to an email.")}</p>
      <a class="btn btn-primary" href="#self-check-tool">{span("Przejdź do ankiety", "Go to the self-check")}</a>
    </aside>
  </div>
</section>

<section class="section muted-band" id="self-check-tool">
  <div class="container">
    <div class="self-check-shell" data-self-check>
      <div class="self-check-start-panel" data-self-check-intro>
        <div class="stack">
          <span class="eyebrow">{span("3 miesiące", "3 months")}</span>
          <h2>{span("Odpowiedz na krótkie pytania o ostatnie 3 miesiące.", "Answer short questions about the last 3 months.")}</h2>
          <p>{span("Wybierz odpowiedź, która najbliżej opisuje Twoje doświadczenie. Nie ma dobrych ani złych odpowiedzi.", "Choose the answer that best describes your experience. There are no right or wrong answers.")}</p>
        </div>
        <button class="btn btn-primary" type="button" data-start-self-check>{span("Start", "Start")}</button>
      </div>

      <div class="self-check-wizard" data-self-check-wizard hidden>
        <div class="wizard-top">
          <div>
            <p class="step-kicker" data-step-count></p>
            <h2 data-step-title></h2>
            <p data-step-help></p>
          </div>
          <button class="btn btn-secondary btn-small" type="button" data-reset-self-check>{span("Reset", "Reset")}</button>
        </div>
        <div class="progress-wrap">
          <div class="progress-track" role="progressbar" aria-valuemin="1" aria-valuemax="7" aria-valuenow="1" aria-label="Postęp autotestu" data-progress-label-pl="Postęp autotestu" data-progress-label-en="Self-check progress" data-progress>
            <span data-progress-bar></span>
          </div>
        </div>
        <p class="sr-only" aria-live="polite" data-self-check-live></p>
        <form data-self-check-form novalidate>
          <div class="question-stack" data-question-area></div>
          <p class="step-error" data-step-error aria-live="polite"></p>
          <div class="wizard-actions">
            <button class="btn btn-secondary" type="button" data-back-step>{span("Wstecz", "Back")}</button>
            <button class="btn btn-primary" type="button" data-next-step>{span("Dalej", "Next")}</button>
          </div>
        </form>
      </div>

      <section class="self-check-results" data-self-check-results aria-live="polite" tabindex="-1" hidden></section>
    </div>
  </div>
</section>

<section class="section" id="support-resources">
  <div class="container">
    <div class="section-head">
      <div>
        <span class="eyebrow">{span("Wsparcie", "Support")}</span>
        <h2>{span("Źródła wsparcia i kolejne kroki.", "Support resources and next steps.")}</h2>
      </div>
      <p>{span("Jeśli temat jedzenia, ciała lub kontroli budzi napięcie, nie musisz przechodzić przez to sama/sam. Poniższe źródła mogą pomóc zacząć rozmowę.", "If food, body image or control feels stressful, you do not have to deal with it alone. These resources can help you start a conversation.")}</p>
    </div>
    <div class="grid-3 resource-grid">
      <article class="card">
        <span class="icon-badge">IE</span>
        <h3>Bodywhys</h3>
        <p>{span("Bodywhys oferuje poufne wsparcie i informacje dla osób z zaburzeniami odżywiania oraz osób martwiących się o kogoś bliskiego.", "Bodywhys offers confidential support and information for people with eating disorders and people worried about someone else.")}</p>
        <a class="read-more" href="https://www.bodywhys.ie/recovery-support-treatment/support-services-2/helpline/" target="_blank" rel="noopener">Bodywhys</a>
      </article>
      <article class="card">
        <span class="icon-badge">PL</span>
        <h3>{span("Pomoc w Polsce", "Support in Poland")}</h3>
        <p>{span("Find a Helpline zbiera aktualne kontakty wsparcia dla osób z trudnościami wokół jedzenia i obrazu ciała w Polsce.", "Find a Helpline lists support contacts for eating and body-image difficulties in Poland.")}</p>
        <a class="read-more" href="https://findahelpline.com/countries/pl/topics/eating-body-image" target="_blank" rel="noopener">Find a Helpline</a>
      </article>
      <article class="card">
        <span class="icon-badge">NFZ</span>
        <h3>{span("Edukacja NFZ", "NFZ education")}</h3>
        <p>{span("Artykuł NFZ wyjaśnia, czym są zaburzenia odżywiania i kiedy warto szukać pomocy.", "The NFZ article explains eating disorders and when it may be worth seeking help.")}</p>
        <a class="read-more" href="https://diety.nfz.gov.pl/porady/zdrowe-nawyki/zaburzenia-odzywiania-co-warto-wiedziec" target="_blank" rel="noopener">NFZ</a>
      </article>
      <article class="card">
        <span class="icon-badge">Global</span>
        <h3>NEDA</h3>
        <p>{span("NEDA udostępnia materiały edukacyjne i zasoby wsparcia dla osób martwiących się zaburzeniami odżywiania.", "NEDA provides educational materials and support resources for people concerned about eating disorders.")}</p>
        <a class="read-more" href="https://www.nationaleatingdisorders.org/screening-tool/" target="_blank" rel="noopener">NEDA</a>
      </article>
    </div>
  </div>
</section>

<section class="section final-cta">
  <div class="container cta-band">
    <div>
      <span class="eyebrow">{span("Konsultacja", "Consultation")}</span>
      <h2>{span("Chcesz porozmawiać o swojej relacji z jedzeniem?", "Would you like to talk about your relationship with food?")}</h2>
      <p>{span("Natalia może pomóc uporządkować codzienne jedzenie i nawyki. Przy podejrzeniu zaburzeń odżywiania warto równolegle skonsultować się z lekarzem lub specjalistą zdrowia psychicznego.", "Natalia can help organise everyday eating and habits. If an eating disorder is a concern, it is worth also speaking with a doctor or mental health professional.")}</p>
    </div>
    <div class="action-row">
      <a class="btn btn-primary" href="index.html#booking">{span("Umów konsultację z Natalią", "Book a consultation with Natalia")}</a>
      <a class="btn btn-secondary" href="mailto:{EMAIL}?subject={subject_pl_url}" data-href-pl="mailto:{EMAIL}?subject={subject_pl_url}" data-href-en="mailto:{EMAIL}?subject={subject_en_url}">{span("Napisz wiadomość", "Send a message")}</a>
    </div>
  </div>
</section>

<section class="section methodology-section">
  <div class="container narrow">
    <details class="methodology-card">
      <summary>{span("Na czym opiera się autotest?", "What is this self-check based on?")}</summary>
      <div class="stack">
        <p>{span("Pytania są inspirowane obszarami uwzględnianymi w uznanych narzędziach przesiewowych i klinicznych opisach zaburzeń odżywiania: ograniczanie jedzenia, epizody utraty kontroli, zachowania kompensacyjne, obraz ciała, unikanie jedzenia, sztywność zasad żywieniowych i sygnały bezpieczeństwa. To nie jest walidowany test diagnostyczny.", "The questions are inspired by domains commonly considered in recognised screening tools and clinical descriptions of eating disorders: restriction, loss-of-control eating, compensatory behaviours, body image, avoidant eating, rigid food rules and safety signals. This is not a validated diagnostic test.")}</p>
        <p>{span("Słowa kluczowe: zaburzenia odżywiania, relacja z jedzeniem, dietetyczka Dublin, polski dietetyk Dublin, konsultacja dietetyczna online.", "Related topics: eating disorder risk, relationship with food, Polish nutritionist Dublin, nutrition consultation online.")}</p>
        <ul class="source-list">
          <li><a href="https://www.nationaleatingdisorders.org/screening-tool/" target="_blank" rel="noopener">NEDA</a></li>
          <li><a href="https://www.nice.org.uk/guidance/ng69" target="_blank" rel="noopener">NICE NG69</a></li>
          <li><a href="https://insideoutinstitute.org.au/resource-library/the-scoff-questionnaire" target="_blank" rel="noopener">SCOFF</a></li>
          <li><a href="https://www.eat-26.com/" target="_blank" rel="noopener">EAT-26</a></li>
          <li><a href="https://insideoutinstitute.org.au/assets/beds-7.pdf" target="_blank" rel="noopener">BEDS-7</a></li>
          <li><a href="https://www.corc.uk.net/outcome-measures-guidance/directory-of-outcome-measures/eating-disorder-examination-questionnaire-ede-q/" target="_blank" rel="noopener">EDE-Q</a></li>
          <li><a href="https://diety.nfz.gov.pl/porady/zdrowe-nawyki/zaburzenia-odzywiania-co-warto-wiedziec" target="_blank" rel="noopener">NFZ</a></li>
        </ul>
      </div>
    </details>
  </div>
</section>
"""
    return page(
        "Autotest relacji z jedzeniem | Natalia Wcisło",
        "Eating Pattern Self-Check | Natalia Wcisło",
        "Anonimowy autotest, który pomaga zauważyć sygnały ryzyka w relacji z jedzeniem, ciałem i kontrolą. Nie zastępuje diagnozy ani konsultacji medycznej.",
        "An anonymous self-check to help notice possible risk signals in your relationship with food, body image and control. It does not replace diagnosis or medical consultation.",
        "autotest",
        main,
        schema=[professional_schema()],
        extra_css=["css/autotest.css"],
        extra_js=["js/autotest.js"],
    )


def blog_page() -> str:
    cards = "".join(article_card(article) for article in ARTICLES)
    main = f"""
<section class="page-hero">
  <div class="container narrow stack">
    <span class="eyebrow">Blog</span>
    <h1>{span("Praktyczny blog o zdrowym odżywianiu, nawykach i spokojniejszej relacji z jedzeniem.", "A practical blog about healthy eating, habits and a calmer relationship with food.")}</h1>
    <p class="lead">{span("Dziesięć startowych artykułów odpowiada na najczęstsze pytania osób, które chcą jeść lepiej bez restrykcji i bez medycznych obietnic.", "Ten starter articles answer common questions from people who want to eat better without restriction or medical promises.")}</p>
  </div>
</section>
<section class="section">
  <div class="container blog-grid">{cards}</div>
</section>
"""
    return page(
        "Blog dietetyczny | Natalia Wcisło Natural Healing",
        "Nutrition Blog | Natalia Wcisło Natural Healing",
        "Blog Natalii Wcisło o zdrowym odżywianiu, insulinooporności, jelitach, planowaniu posiłków i konsultacjach dietetycznych online.",
        "Natalia Wcisło's blog about healthy eating, insulin resistance, gut health, meal planning and online nutrition consultation.",
        "blog",
        main,
        schema=[professional_schema()],
    )


def contact_page() -> str:
    main = f"""
<section class="page-hero">
  <div class="container narrow stack">
    <span class="eyebrow">{span("Kontakt", "Contact")}</span>
    <h1>{span("Napisz do Natalii i zapytaj o konsultację.", "Contact Natalia and ask about a consultation.")}</h1>
    <p class="lead">{span("Najprostsza droga to e-mail, Instagram, Facebook albo formularz, który przygotuje wiadomość do wysłania.", "The simplest route is email, Instagram, Facebook or the form that prepares a message for you to send.")}</p>
  </div>
</section>

<section class="section">
  <div class="container split contact-split">
    <div class="stack">
      <div class="media-frame portrait-small">
        <img src="assets/images/natalia-contact.jpg" alt="Natalia Wcisło, Natural Healing Dublin" data-alt-pl="Natalia Wcisło, Natural Healing Dublin" data-alt-en="Natalia Wcisło, Natural Healing Dublin">
      </div>
      <div class="contact-list">
        <a class="contact-item" href="mailto:{EMAIL}"><span class="icon-badge">@</span><span><strong>Email</strong><small>{EMAIL}</small></span></a>
        <a class="contact-item" href="{INSTAGRAM}" target="_blank" rel="noopener"><span class="icon-badge">IG</span><span><strong>Instagram</strong><small>@natural.healing.dublin</small></span></a>
        <a class="contact-item" href="{FACEBOOK}" target="_blank" rel="noopener"><span class="icon-badge">FB</span><span><strong>Facebook</strong><small>Natural Healing</small></span></a>
      </div>
    </div>
    <div class="stack">
      <span class="eyebrow">{span("Formularz", "Form")}</span>
      <h2>{span("Opisz krótko, czego potrzebujesz.", "Briefly describe what you need.")}</h2>
      {booking_form("contact-booking")}
    </div>
  </div>
</section>
"""
    return page(
        "Kontakt | Natalia Wcisło Natural Healing Dublin",
        "Contact | Natalia Wcisło Natural Healing Dublin",
        "Kontakt do Natalii Wcisło: Dietolozki@gmail.com, Instagram, Facebook i formularz zapytania o konsultację dietetyczną online.",
        "Contact Natalia Wcisło: Dietolozki@gmail.com, Instagram, Facebook and a form for online nutrition consultation enquiries.",
        "contact",
        main,
        schema=[professional_schema()],
    )


def article_page(article: dict) -> str:
    pl_sections = "\n".join(f"<h2>{escape(title)}</h2><p>{escape(body)}</p>" for title, body in article["sections_pl"])
    en_sections = "\n".join(f"<h2>{escape(title)}</h2><p>{escape(body)}</p>" for title, body in article["sections_en"])
    related = "".join(
        f'<li><a href="{a["slug"]}.html">{span(a["title_pl"], a["title_en"])}</a></li>'
        for a in ARTICLES[:4]
        if a["slug"] != article["slug"]
    )
    main = f"""
<section class="page-hero article-hero">
  <div class="container narrow stack">
    <a class="back-link" href="../blog.html">{span("Wróć do bloga", "Back to blog")}</a>
    <span class="eyebrow">{span(article["category_pl"], article["category_en"])} • {article["minutes"]}</span>
    <h1>{span(article["title_pl"], article["title_en"])}</h1>
    <p class="lead">{span(article["desc_pl"], article["desc_en"])}</p>
    <p class="article-meta">{span("Opublikowano", "Published")} <time datetime="{TODAY}">25.04.2026</time></p>
  </div>
</section>
<section class="section">
  <div class="container article-layout">
    <article class="article-body">
      <div class="lang-pl-content">{pl_sections}</div>
      <div class="lang-en-content">{en_sections}</div>
      <div class="disclaimer">
        <strong>{span("Nota bezpieczeństwa", "Safety note")}</strong>
        <p>{span("Ten artykuł ma charakter edukacyjny. Nie zastępuje diagnozy, leczenia ani indywidualnej konsultacji medycznej lub dietetycznej.", "This article is educational. It does not replace diagnosis, treatment or an individual medical or nutrition consultation.")}</p>
      </div>
      <div class="article-cta">
        <h2>{span("Potrzebujesz indywidualnego planu?", "Need an individual plan?")}</h2>
        <p>{span("Wyślij krótkie zapytanie i opisz, czego potrzebujesz w konsultacji.", "Send a short enquiry and describe what you need from a consultation.")}</p>
        <a class="btn btn-primary" href="../index.html#booking">{span("Umów wizytę", "Book a visit")}</a>
      </div>
    </article>
    <aside class="article-aside" aria-label="Article side information">
      <div class="side-box">
        <strong>{span("Temat", "Topic")}</strong>
        <p>{span(article["category_pl"], article["category_en"])}</p>
      </div>
      <div class="side-box">
        <strong>{span("Czytaj także", "Read also")}</strong>
        <ul class="related-list">{related}</ul>
      </div>
      <div class="side-box">
        <strong>{span("Kontakt", "Contact")}</strong>
        <p><a href="mailto:{EMAIL}">{EMAIL}</a></p>
      </div>
    </aside>
  </div>
</section>
"""
    return page(
        f"{article['title_pl']} | Natural Healing",
        f"{article['title_en']} | Natural Healing",
        article["desc_pl"],
        article["desc_en"],
        "blog",
        main,
        prefix="../",
        schema=[professional_schema("../"), article_schema(article, "../")],
    )


CSS = r"""
:root {
  --ink: #263126;
  --muted: #657062;
  --sage: #71866a;
  --sage-dark: #3f553f;
  --sage-soft: #e3ebde;
  --cream: #fbf7ef;
  --warm: #f3e7d7;
  --clay: #bd765b;
  --clay-dark: #8f4f3e;
  --white: #fffdf8;
  --line: rgba(38, 49, 38, .15);
  --shadow: 0 18px 48px rgba(38, 49, 38, .10);
  --max: 1160px;
  --radius: 8px;
}

* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  margin: 0;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  color: var(--ink);
  background: var(--cream);
  line-height: 1.65;
  overflow-x: hidden;
}
body.lang-pl .lang-en-content,
body.lang-en .lang-pl-content { display: none !important; }

a { color: inherit; text-decoration: none; }
a:hover { color: var(--sage-dark); }
img { display: block; max-width: 100%; }
button, input, textarea, select { font: inherit; }
button:focus-visible, a:focus-visible, input:focus-visible, textarea:focus-visible, select:focus-visible {
  outline: 3px solid rgba(113, 134, 106, .35);
  outline-offset: 3px;
}

.skip-link {
  position: absolute;
  top: -4rem;
  left: 1rem;
  z-index: 100;
  background: var(--sage-dark);
  color: white;
  padding: .7rem 1rem;
  border-radius: 999px;
}
.skip-link:focus { top: 1rem; }

.container {
  width: min(var(--max), calc(100% - 40px));
  margin-inline: auto;
}
.narrow { max-width: 900px; }
.section { padding: 88px 0; }
.muted-band {
  background: #f5efe4;
  border-block: 1px solid rgba(38, 49, 38, .08);
}
.stack { display: grid; gap: 18px; align-content: start; }
.hero-copy, .stack, .card, .form-card, .article-body { min-width: 0; }
.split {
  display: grid;
  grid-template-columns: minmax(0, .92fr) minmax(0, 1.08fr);
  gap: 56px;
  align-items: center;
}
.grid-3, .blog-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 20px;
}

.site-header {
  position: sticky;
  top: 0;
  z-index: 40;
  background: rgba(251, 247, 239, .94);
  border-bottom: 1px solid rgba(38, 49, 38, .1);
  backdrop-filter: blur(18px);
}
.header-inner {
  width: min(var(--max), calc(100% - 40px));
  min-height: 78px;
  margin-inline: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
}
.brand {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  font-weight: 800;
  min-width: max-content;
}
.brand img { width: 44px; height: 44px; }
.brand small {
  display: block;
  color: var(--muted);
  font-size: .76rem;
  text-transform: uppercase;
  font-weight: 700;
}
.nav {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
  flex-wrap: wrap;
}
.nav a, .lang-btn, .nav-toggle {
  border: 0;
  background: transparent;
  color: var(--muted);
  font-weight: 800;
  cursor: pointer;
}
.nav a, .lang-btn {
  border-radius: 999px;
  padding: .58rem .78rem;
}
.nav a:hover, .nav a[aria-current="page"], .lang-btn.active {
  background: var(--sage-soft);
  color: var(--sage-dark);
}
.nav .nav-cta {
  background: var(--ink);
  color: white;
  padding-inline: 1rem;
}
.nav .nav-cta:hover { background: var(--sage-dark); color: white; }
.lang-switch {
  display: inline-flex;
  gap: 2px;
  padding: 3px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: rgba(255, 253, 248, .75);
}
.lang-btn { font-size: .88rem; padding: .38rem .62rem; }
.nav-toggle { display: none; align-items: center; gap: 8px; }
.nav-toggle-mark { display: grid; gap: 4px; }
.nav-toggle-mark span {
  width: 19px;
  height: 2px;
  background: var(--ink);
  display: block;
}

h1, h2, h3 {
  margin: 0;
  line-height: 1.08;
  letter-spacing: 0;
  overflow-wrap: anywhere;
}
h1, h2 {
  font-family: Georgia, "Times New Roman", serif;
  font-weight: 650;
}
h1 { font-size: 4.2rem; max-width: 960px; }
h2 { font-size: 2.8rem; }
h3 { font-size: 1.35rem; }
p { margin: 0; color: var(--muted); }
.lead {
  font-size: 1.2rem;
  color: #4c594c;
  max-width: 780px;
}
.eyebrow {
  display: inline-flex;
  width: fit-content;
  align-items: center;
  gap: 8px;
  color: var(--clay-dark);
  background: rgba(189, 118, 91, .12);
  border: 1px solid rgba(189, 118, 91, .18);
  padding: .42rem .72rem;
  border-radius: 999px;
  font-size: .78rem;
  font-weight: 850;
  text-transform: uppercase;
}
.eyebrow::before {
  content: "";
  width: 7px;
  height: 7px;
  background: var(--clay);
  border-radius: 50%;
}

.hero {
  position: relative;
  min-height: calc(100svh - 78px);
  padding: 0;
  overflow: hidden;
  background:
    linear-gradient(90deg, rgba(251, 247, 239, .99) 0%, rgba(251, 247, 239, .96) 44%, rgba(227, 235, 222, .86) 72%, rgba(189, 118, 91, .16) 100%),
    #f6efe4;
  border-bottom: 1px solid rgba(38, 49, 38, .08);
}
.hero::before {
  content: "";
  position: absolute;
  inset: 0;
  z-index: 2;
  pointer-events: none;
  background: linear-gradient(90deg, rgba(251, 247, 239, .98) 0%, rgba(251, 247, 239, .86) 45%, rgba(251, 247, 239, .2) 72%, rgba(251, 247, 239, 0) 100%);
}
.hero::after {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 22%;
  z-index: 2;
  pointer-events: none;
  background: linear-gradient(180deg, rgba(251, 247, 239, 0), var(--cream));
}
.hero-inner {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1.05fr) minmax(320px, .78fr);
  gap: 54px;
  align-items: center;
  min-height: calc(100svh - 78px);
}
.hero-copy {
  position: relative;
  z-index: 3;
  display: grid;
  gap: 22px;
  max-width: 780px;
  padding: 84px 0 108px;
}
.hero h1 {
  max-width: 820px;
  font-size: 4.75rem;
}
.action-row {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
}
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 46px;
  padding: .78rem 1.08rem;
  border-radius: 999px;
  border: 1px solid transparent;
  font-weight: 850;
  cursor: pointer;
  transition: transform .18s ease, box-shadow .18s ease, background .18s ease;
}
.btn:hover { transform: translateY(-1px); }
.btn-primary {
  background: var(--sage-dark);
  color: white;
  box-shadow: 0 12px 24px rgba(63, 85, 63, .18);
}
.btn-primary:hover { color: white; background: #304430; }
.btn-secondary {
  background: var(--white);
  border-color: var(--line);
  color: var(--ink);
}
.btn-secondary:hover { color: var(--ink); box-shadow: var(--shadow); }
.btn-terra {
  background: var(--clay);
  color: white;
}
.btn-terra:hover { color: white; background: var(--clay-dark); }
.hero-portrait {
  position: absolute;
  z-index: 1;
  right: -62px;
  bottom: -78px;
  width: min(760px, 58%);
  height: calc(100% + 110px);
  margin: 0;
  background: transparent;
  border: 0;
  border-radius: 0;
  box-shadow: none;
  padding: 0;
  pointer-events: none;
}
.hero-portrait img {
  width: 100%;
  height: 100%;
  max-width: none;
  aspect-ratio: auto;
  object-fit: contain;
  object-position: right bottom;
  border-radius: 0;
  filter: drop-shadow(0 34px 42px rgba(38, 49, 38, .18));
}
.hero-portrait figcaption {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
.trust-row {
  position: relative;
  z-index: 3;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-top: 10px;
}
.trust-row div {
  background: rgba(255, 253, 248, .72);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  padding: 14px;
}
.trust-row strong, .trust-row span { display: block; }
.trust-row span { color: var(--muted); font-size: .92rem; }

.section-head {
  display: flex;
  justify-content: space-between;
  align-items: end;
  gap: 32px;
  margin-bottom: 34px;
}
.section-head p { max-width: 560px; }
.media-frame {
  border-radius: var(--radius);
  overflow: hidden;
  box-shadow: var(--shadow);
  background: var(--warm);
  border: 1px solid var(--line);
}
.media-frame img {
  width: 100%;
  aspect-ratio: 4 / 3;
  object-fit: cover;
}
.portrait-small img {
  aspect-ratio: 4 / 5;
  object-position: center top;
}
.mini-list {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.mini-list span {
  background: var(--sage-soft);
  color: var(--sage-dark);
  border-radius: 999px;
  padding: .42rem .72rem;
  font-weight: 800;
  font-size: .92rem;
}
.card {
  background: rgba(255, 253, 248, .82);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  padding: 24px;
}
.card h3 { margin-bottom: 10px; }
.icon-badge {
  display: inline-grid;
  place-items: center;
  min-width: 42px;
  height: 42px;
  margin-bottom: 16px;
  border-radius: var(--radius);
  background: var(--sage-soft);
  color: var(--sage-dark);
  font-weight: 900;
}
.testimonial {
  min-height: 210px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.testimonial p {
  color: #3c473c;
  font-weight: 700;
}
.placeholder-label {
  width: fit-content;
  border-radius: 999px;
  padding: .3rem .58rem;
  background: rgba(189, 118, 91, .12);
  color: var(--clay-dark);
  font-size: .78rem;
  font-weight: 850;
}
.book-panel {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  align-items: center;
  gap: 32px;
  background: var(--ink);
  color: white;
  border-radius: var(--radius);
  padding: 30px;
}
.book-panel p { color: rgba(255, 255, 255, .76); }
.book-panel img {
  width: min(100%, 220px);
  aspect-ratio: 2 / 3;
  object-fit: cover;
  border-radius: var(--radius);
  box-shadow: 0 20px 36px rgba(0, 0, 0, .25);
}
.book-panel .eyebrow {
  background: rgba(255, 255, 255, .12);
  color: #f7d5c4;
}

.form-split { align-items: start; }
.contact-note {
  display: grid;
  gap: 4px;
  padding: 16px;
  background: var(--white);
  border: 1px solid var(--line);
  border-radius: var(--radius);
}
.form-card {
  background: var(--white);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  padding: 26px;
}
.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}
.field { display: grid; gap: 7px; }
.field.full { grid-column: 1 / -1; }
label { color: var(--ink); font-weight: 850; }
.optional { color: var(--muted); font-size: .86rem; font-weight: 650; }
input, textarea, select {
  width: 100%;
  min-height: 46px;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: #fffdfa;
  color: var(--ink);
  padding: .78rem .86rem;
}
textarea { min-height: 132px; resize: vertical; }
input:focus, textarea:focus, select:focus {
  border-color: var(--sage);
  box-shadow: 0 0 0 4px rgba(113, 134, 106, .16);
  outline: none;
}
.checkbox {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  color: var(--muted);
  font-size: .94rem;
  font-weight: 650;
}
.checkbox input { width: auto; min-height: auto; margin-top: .35rem; }
.form-actions { align-items: start; }
.form-status { color: var(--sage-dark); font-weight: 800; }

.card-kicker {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  color: var(--sage-dark);
  font-size: .82rem;
  font-weight: 850;
}
.card-kicker span:first-child {
  background: var(--sage-soft);
  border-radius: 999px;
  padding: .28rem .56rem;
}
.blog-card {
  min-height: 312px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.blog-card .read-more {
  margin-top: auto;
  color: var(--sage-dark);
  font-weight: 900;
}

.page-hero { padding: 78px 0 44px; }
.book-layout {
  display: grid;
  grid-template-columns: minmax(280px, .75fr) minmax(0, 1.2fr);
  gap: 54px;
  align-items: center;
}
.book-cover-card {
  background: var(--white);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  padding: 22px;
}
.book-cover-card img {
  width: min(100%, 420px);
  aspect-ratio: 2 / 3;
  object-fit: cover;
  margin-inline: auto;
  border-radius: var(--radius);
}
.info-list {
  display: grid;
  gap: 10px;
  margin-top: 8px;
}
.info-list div {
  display: flex;
  justify-content: space-between;
  gap: 18px;
  padding: 12px 0;
  border-bottom: 1px solid var(--line);
}
.info-list span { color: var(--muted); font-weight: 800; }
.feature-list {
  display: grid;
  gap: 14px;
}
.feature-list div, .side-box, .article-cta, .disclaimer, .cta-band {
  background: var(--white);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  padding: 22px;
}
.cta-band {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
}
.final-cta { padding-top: 40px; }

.article-layout {
  display: grid;
  grid-template-columns: minmax(0, 760px) 300px;
  gap: 42px;
  align-items: start;
}
.article-body {
  background: var(--white);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  padding: 42px;
}
.article-body h2 {
  font-family: Georgia, "Times New Roman", serif;
  font-size: 2rem;
  margin: 34px 0 12px;
}
.article-body h2:first-child { margin-top: 0; }
.article-body p { font-size: 1.04rem; }
.article-meta { font-size: .94rem; }
.back-link {
  color: var(--sage-dark);
  font-weight: 850;
}
.disclaimer {
  margin-top: 32px;
  border-left: 4px solid var(--clay);
  box-shadow: none;
}
.article-cta {
  margin-top: 24px;
  display: grid;
  gap: 14px;
  background: #f5efe4;
  box-shadow: none;
}
.article-aside {
  position: sticky;
  top: 104px;
  display: grid;
  gap: 14px;
}
.related-list {
  margin: 10px 0 0;
  padding-left: 1.1rem;
  color: var(--muted);
}
.related-list li + li { margin-top: 8px; }
.related-list a { text-decoration: underline; text-underline-offset: 3px; }

.contact-split { align-items: start; }
.contact-list {
  display: grid;
  gap: 12px;
}
.contact-item {
  display: flex;
  align-items: center;
  gap: 14px;
  background: var(--white);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  padding: 16px;
}
.contact-item small {
  display: block;
  color: var(--muted);
  overflow-wrap: anywhere;
}

.site-footer {
  background: var(--ink);
  color: white;
  padding: 54px 0 26px;
}
.footer-grid {
  display: grid;
  grid-template-columns: 1.25fr .75fr .9fr;
  gap: 34px;
  align-items: start;
}
.footer-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}
.footer-brand img { width: 42px; height: 42px; }
.site-footer p, .site-footer a, .site-footer li { color: rgba(255, 255, 255, .72); }
.site-footer a:hover { color: white; }
.footer-links {
  list-style: none;
  margin: 14px 0 0;
  padding: 0;
  display: grid;
  gap: 8px;
}
.footer-bottom {
  border-top: 1px solid rgba(255, 255, 255, .12);
  margin-top: 36px;
  padding-top: 18px;
  display: flex;
  justify-content: space-between;
  gap: 18px;
  flex-wrap: wrap;
  color: rgba(255, 255, 255, .66);
  font-size: .92rem;
}

@media (max-width: 980px) {
  h1 { font-size: 3.25rem; }
  .hero h1 { font-size: 3.35rem; }
  h2 { font-size: 2.35rem; }
  .hero-inner, .split, .book-layout, .article-layout {
    grid-template-columns: 1fr;
  }
  .grid-3, .blog-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .article-aside { position: static; }
}

@media (max-width: 760px) {
  .container, .header-inner { width: min(calc(100% - 28px), var(--max)); }
  .section { padding: 64px 0; }
  .page-hero { padding: 56px 0 28px; }
  .header-inner {
    min-height: 70px;
    flex-wrap: wrap;
  }
  .nav-toggle { display: inline-flex; margin-left: auto; }
  .nav {
    display: none;
    width: 100%;
    align-items: stretch;
    justify-content: start;
    padding-bottom: 14px;
  }
  .nav.is-open { display: grid; grid-template-columns: 1fr 1fr; }
  .nav a, .lang-switch { width: 100%; justify-content: center; }
  h1 { font-size: 2.25rem; }
  .hero h1 { font-size: 2rem; }
  h2 { font-size: 2rem; }
  .hero {
    min-height: auto;
  }
  .hero::before {
    background: linear-gradient(180deg, rgba(251, 247, 239, .98) 0%, rgba(251, 247, 239, .9) 48%, rgba(251, 247, 239, .24) 76%, rgba(251, 247, 239, 0) 100%);
  }
  .hero::after { height: 14%; }
  .hero-inner {
    min-height: auto;
    display: grid;
  }
  .hero-copy {
    padding: 54px 0 18px;
    max-width: 350px;
  }
  .hero-portrait {
    position: relative;
    right: auto;
    bottom: auto;
    justify-self: center;
    width: min(100%, 460px);
    height: 540px;
    margin: -10px auto -22px;
  }
  .hero-portrait img {
    object-position: center bottom;
  }
  .trust-row, .grid-3, .blog-grid, .form-grid, .footer-grid {
    grid-template-columns: 1fr;
  }
  .section-head, .cta-band, .book-panel {
    display: grid;
  }
  .book-panel { grid-template-columns: 1fr; }
  .form-card, .article-body { padding: 22px; }
  .footer-bottom { display: grid; }
}
"""


JS = r"""
(() => {
  const html = document.documentElement;
  const body = document.body;
  const key = 'natalia-site-lang';
  const langButtons = document.querySelectorAll('[data-set-lang]');
  const nav = document.querySelector('#site-nav');
  const navToggle = document.querySelector('.nav-toggle');

  function storedLang() {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      return null;
    }
  }

  function saveLang(lang) {
    try {
      localStorage.setItem(key, lang);
    } catch (error) {
      // localStorage may be unavailable in some privacy modes.
    }
  }

  function setMeta(selector, value) {
    const node = document.querySelector(selector);
    if (node && value) node.setAttribute('content', value);
  }

  function setLang(lang) {
    const safeLang = lang === 'en' ? 'en' : 'pl';
    html.lang = safeLang;
    body.classList.toggle('lang-en', safeLang === 'en');
    body.classList.toggle('lang-pl', safeLang === 'pl');
    saveLang(safeLang);

    langButtons.forEach((button) => {
      const active = button.dataset.setLang === safeLang;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });

    document.querySelectorAll('[data-text-pl]').forEach((node) => {
      node.textContent = safeLang === 'en' ? node.dataset.textEn : node.dataset.textPl;
    });
    document.querySelectorAll('[data-placeholder-pl]').forEach((node) => {
      node.setAttribute('placeholder', safeLang === 'en' ? node.dataset.placeholderEn : node.dataset.placeholderPl);
    });
    document.querySelectorAll('[data-alt-pl]').forEach((node) => {
      node.setAttribute('alt', safeLang === 'en' ? node.dataset.altEn : node.dataset.altPl);
    });
    document.querySelectorAll('[data-href-pl]').forEach((node) => {
      node.setAttribute('href', safeLang === 'en' ? node.dataset.hrefEn : node.dataset.hrefPl);
    });

    if (body.dataset.titlePl && body.dataset.titleEn) {
      document.title = safeLang === 'en' ? body.dataset.titleEn : body.dataset.titlePl;
    }
    const description = document.querySelector('meta[name="description"]');
    if (description) {
      description.content = safeLang === 'en' ? description.dataset.descriptionEn : description.dataset.descriptionPl;
    }
    const ogTitle = document.querySelector('[data-og-title-pl]');
    const ogDescription = document.querySelector('[data-og-description-pl]');
    if (ogTitle) ogTitle.content = safeLang === 'en' ? ogTitle.dataset.ogTitleEn : ogTitle.dataset.ogTitlePl;
    if (ogDescription) ogDescription.content = safeLang === 'en' ? ogDescription.dataset.ogDescriptionEn : ogDescription.dataset.ogDescriptionPl;
    setMeta('[data-og-locale]', safeLang === 'en' ? 'en_IE' : 'pl_PL');
  }

  setLang(storedLang() || 'pl');
  langButtons.forEach((button) => {
    button.addEventListener('click', () => {
      setLang(button.dataset.setLang);
      if (nav && navToggle) {
        nav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  if (nav && navToggle) {
    navToggle.addEventListener('click', () => {
      const open = !nav.classList.contains('is-open');
      nav.classList.toggle('is-open', open);
      navToggle.setAttribute('aria-expanded', String(open));
    });
  }

  document.querySelectorAll('[data-booking-form]').forEach((form) => {
    const status = form.querySelector('[data-form-status]');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const lang = html.lang === 'en' ? 'en' : 'pl';

      if (!form.reportValidity()) return;

      const data = new FormData(form);
      const labels = lang === 'en'
        ? {
            subject: 'Nutrition consultation request',
            name: 'Name',
            email: 'Email',
            phone: 'Phone',
            preferredLanguage: 'Preferred language',
            type: 'Consultation type',
            message: 'Message',
            consent: 'Consent to contact'
          }
        : {
            subject: 'Zapytanie o konsultację żywieniową',
            name: 'Imię i nazwisko',
            email: 'Email',
            phone: 'Telefon',
            preferredLanguage: 'Preferowany język',
            type: 'Typ konsultacji',
            message: 'Wiadomość',
            consent: 'Zgoda na kontakt'
          };

      const lines = [
        `${labels.name}: ${data.get('name') || ''}`,
        `${labels.email}: ${data.get('email') || ''}`,
        `${labels.phone}: ${data.get('phone') || ''}`,
        `${labels.preferredLanguage}: ${data.get('preferred_language') || ''}`,
        `${labels.type}: ${data.get('type') || ''}`,
        `${labels.consent}: yes`,
        '',
        `${labels.message}:`,
        `${data.get('message') || ''}`
      ];

      const mailto = `mailto:Dietolozki@gmail.com?subject=${encodeURIComponent(labels.subject)}&body=${encodeURIComponent(lines.join('\n'))}`;
      if (status) status.textContent = lang === 'en' ? 'Opening your email app...' : 'Otwieram aplikację mailową...';
      window.location.href = mailto;
    });
  });
})();
"""


README = """# Natural Healing - Natalia Wcisło

Static bilingual website for Natalia Wcisło, a Polish nutrition professional in Dublin.

## Pages

- `index.html` - home page with hero, intro, testimonials placeholders, book teaser and booking form
- `book.html` - coming-soon book landing page
- `blog.html` - blog index with 10 starter articles
- `autotest.html` - non-diagnostic eating pattern self-check
- `articles/` - dedicated bilingual article pages
- `contact.html` - contact links and booking form

## Language

Polish is the default language. The PL / EN switch is handled in `js/main.js` and persists the user's choice in `localStorage`.

## Photos

Optimized copies live in `assets/images/`:

- `natalia-hero.jpg`
- `natalia-hero-cutout.png`
- `natalia-about.jpg`
- `natalia-contact.jpg`
- `natalia-services-banner.jpg`
- `depression-food-japan-cover.png`

Original source files are left untouched outside the site folder.
The transparent homepage hero cutout can be regenerated with `python3 tools/create_cutout.py`.
The current book cover can be regenerated with `python3 tools/create_book_cover.py`.

## Placeholders

Patient testimonials are placeholders and must be replaced only with real, approved testimonials before publication.

The book is now positioned as `Depresja i jedzenie. Lekcja z Japonii` / `Depression and Food: A Lesson from Japan`. The current cover is a designed working cover at `assets/images/depression-food-japan-cover.png`. To add the final cover later, replace that file or update the image path and alt text in `tools/build_site.py`, then regenerate the site.

## Forms

Forms use a `mailto:` fallback to `Dietolozki@gmail.com`. For production, replace the submit handler in `js/main.js` with a secure form endpoint, serverless function or booking tool, and add a privacy policy plus GDPR/RODO copy.

## Eating pattern self-check

The self-check lives in `autotest.html`, with questions and scoring in `js/autotest.js` and page-specific styles in `css/autotest.css`. It is educational and non-diagnostic. Answers are kept in memory only, are not stored in `localStorage`, are not added to URLs and are not sent anywhere.
"""


def write_file(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def main() -> None:
    ARTICLES_DIR.mkdir(exist_ok=True)
    for file in ARTICLES_DIR.glob("*.html"):
        file.unlink()

    write_file(ROOT / "index.html", home_page())
    write_file(ROOT / "book.html", book_page())
    write_file(ROOT / "blog.html", blog_page())
    write_file(ROOT / "autotest.html", autotest_page())
    write_file(ROOT / "contact.html", contact_page())
    for article in ARTICLES:
        write_file(ARTICLES_DIR / f"{article['slug']}.html", article_page(article))

    write_file(ROOT / "css" / "styles.css", CSS.strip() + "\n")
    write_file(ROOT / "js" / "main.js", JS.strip() + "\n")
    write_file(ROOT / "README.md", README)


if __name__ == "__main__":
    main()
