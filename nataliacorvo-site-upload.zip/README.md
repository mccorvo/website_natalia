# Natural Healing - Natalia Wcisło

Static bilingual website for Natalia Wcisło, a Polish nutrition professional in Dublin.

## Pages

- `index.html` - home page with hero, intro, testimonials placeholders, book teaser and booking form
- `book.html` - coming-soon book landing page
- `blog.html` - blog index with 10 starter articles
- `autotest.html` - non-diagnostic eating pattern self-check
- `articles/` - dedicated bilingual article pages
- `contact.html` - contact links and booking form

## Language

Polish is the default language. The PL / EN switch is handled in `js/main.js` and persists the user's choice in `localStorage`.

## Photos

Optimized copies live in `assets/images/`:

- `natalia-hero.jpg`
- `natalia-hero-cutout.png`
- `natalia-about.jpg`
- `natalia-contact.jpg`
- `natalia-services-banner.jpg`
- `depression-food-japan-cover.png`

Original source files are left untouched outside the site folder.
The transparent homepage hero cutout can be regenerated with `python3 tools/create_cutout.py`.
The current book cover can be regenerated with `python3 tools/create_book_cover.py`.

## Placeholders

Patient testimonials are placeholders and must be replaced only with real, approved testimonials before publication.

The book is now positioned as `Depresja i jedzenie. Lekcja z Japonii` / `Depression and Food: A Lesson from Japan`. The current cover is a designed working cover at `assets/images/depression-food-japan-cover.png`. To add the final cover later, replace that file or update the image path and alt text in `tools/build_site.py`, then regenerate the site.

## Forms

Forms use a `mailto:` fallback to `Dietolozki@gmail.com`. For production, replace the submit handler in `js/main.js` with a secure form endpoint, serverless function or booking tool, and add a privacy policy plus GDPR/RODO copy.

## Eating pattern self-check

The self-check lives in `autotest.html`, with questions and scoring in `js/autotest.js` and page-specific styles in `css/autotest.css`. It is educational and non-diagnostic. Answers are kept in memory only, are not stored in `localStorage`, are not added to URLs and are not sent anywhere.
