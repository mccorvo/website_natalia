(() => {
  const root = document.querySelector('[data-self-check]');
  if (!root) return;

  const email = 'Dietolozki@gmail.com';
  const answers = {};
  let currentStep = 0;

  const els = {
    intro: root.querySelector('[data-self-check-intro]'),
    wizard: root.querySelector('[data-self-check-wizard]'),
    results: root.querySelector('[data-self-check-results]'),
    start: root.querySelector('[data-start-self-check]'),
    reset: root.querySelector('[data-reset-self-check]'),
    back: root.querySelector('[data-back-step]'),
    next: root.querySelector('[data-next-step]'),
    form: root.querySelector('[data-self-check-form]'),
    stepCount: root.querySelector('[data-step-count]'),
    stepTitle: root.querySelector('[data-step-title]'),
    stepHelp: root.querySelector('[data-step-help]'),
    questionArea: root.querySelector('[data-question-area]'),
    progress: root.querySelector('[data-progress]'),
    progressBar: root.querySelector('[data-progress-bar]'),
    error: root.querySelector('[data-step-error]'),
    live: root.querySelector('[data-self-check-live]')
  };

  const domains = {
    restriction: {
      pl: 'Sygnały restrykcyjnego jedzenia i kontroli',
      en: 'Restrictive eating and control signals'
    },
    binge_loss_control: {
      pl: 'Sygnały jedzenia z utratą kontroli',
      en: 'Loss-of-control eating signals'
    },
    compensatory_behaviours: {
      pl: 'Sygnały zachowań kompensacyjnych',
      en: 'Compensatory behaviour signals'
    },
    body_image: {
      pl: 'Sygnały silnego napięcia wokół ciała i sylwetki',
      en: 'Body image and shape-concern signals'
    },
    arfid_like_avoidance: {
      pl: 'Sygnały unikającego lub ograniczającego wzorca jedzenia',
      en: 'Avoidant or restrictive intake signals'
    },
    orthorexia_like_rigidity: {
      pl: "Sygnały sztywności wokół 'zdrowego' jedzenia",
      en: "Rigidity around 'healthy eating' signals"
    }
  };

  const questions = [
    {
      id: 'restriction_1',
      domain: 'restriction',
      pl: 'Czy celowo ograniczasz jedzenie, nawet gdy jesteś głodna/y?',
      en: 'Do you intentionally restrict food even when you are hungry?'
    },
    {
      id: 'restriction_2',
      domain: 'restriction',
      pl: 'Czy unikasz posiłków, ponieważ boisz się przytyć lub stracić kontrolę?',
      en: 'Do you avoid meals because you fear gaining weight or losing control?'
    },
    {
      id: 'restriction_3',
      domain: 'restriction',
      pl: "Czy lista produktów, które uważasz za 'dozwolone', staje się coraz krótsza?",
      en: "Is the list of foods you consider 'allowed' becoming smaller?"
    },
    {
      id: 'restriction_4',
      domain: 'restriction',
      pl: 'Czy czujesz silny niepokój, gdy musisz zjeść coś poza swoim planem?',
      en: 'Do you feel strong anxiety when you have to eat something outside your plan?'
    },
    {
      id: 'binge_1',
      domain: 'binge_loss_control',
      pl: 'Czy zdarzają Ci się epizody jedzenia znacznie większej ilości jedzenia, niż planowałaś/eś?',
      en: 'Do you have episodes of eating much more food than you intended?'
    },
    {
      id: 'binge_2',
      domain: 'binge_loss_control',
      pl: 'Czy podczas takich epizodów trudno Ci przestać jeść?',
      en: 'During these episodes, is it difficult to stop eating?'
    },
    {
      id: 'binge_3',
      domain: 'binge_loss_control',
      pl: 'Czy po takich epizodach odczuwasz wstyd, winę lub obrzydzenie do siebie?',
      en: 'After these episodes, do you feel shame, guilt or disgust with yourself?'
    },
    {
      id: 'binge_4',
      domain: 'binge_loss_control',
      pl: 'Czy jesz w ukryciu z powodu wstydu lub lęku przed oceną?',
      en: 'Do you eat in secret because of shame or fear of judgment?'
    },
    {
      id: 'comp_1',
      domain: 'compensatory_behaviours',
      pl: "Czy próbujesz 'odrobić' jedzenie przez nadmierne ćwiczenia?",
      en: "Do you try to 'make up for' eating through excessive exercise?"
    },
    {
      id: 'comp_2',
      domain: 'compensatory_behaviours',
      pl: 'Czy prowokujesz wymioty po jedzeniu?',
      en: 'Do you make yourself vomit after eating?'
    },
    {
      id: 'comp_3',
      domain: 'compensatory_behaviours',
      pl: 'Czy używasz środków przeczyszczających, moczopędnych lub tabletek odchudzających, aby kontrolować wagę lub kształt ciała?',
      en: 'Do you use laxatives, diuretics or diet pills to control weight or body shape?'
    },
    {
      id: 'comp_4',
      domain: 'compensatory_behaviours',
      pl: "Czy po zjedzeniu 'za dużo' stosujesz głodówki lub bardzo restrykcyjne dni?",
      en: "After eating 'too much', do you fast or have very restrictive days?"
    },
    {
      id: 'body_1',
      domain: 'body_image',
      pl: 'Czy Twoja samoocena mocno zależy od wagi, sylwetki lub wyglądu brzucha?',
      en: 'Does your self-worth strongly depend on your weight, shape or stomach appearance?'
    },
    {
      id: 'body_2',
      domain: 'body_image',
      pl: 'Czy często sprawdzasz ciało w lustrze, na wadze, zdjęciach lub przez dotykanie konkretnych miejsc?',
      en: 'Do you often check your body in mirrors, on the scale, in photos or by touching specific areas?'
    },
    {
      id: 'body_3',
      domain: 'body_image',
      pl: 'Czy unikasz spotkań, ubrań, zdjęć lub sytuacji społecznych przez wygląd ciała?',
      en: 'Do you avoid social situations, clothes or photos because of body appearance?'
    },
    {
      id: 'body_4',
      domain: 'body_image',
      pl: 'Czy myśli o jedzeniu, wadze lub sylwetce zajmują dużą część dnia?',
      en: 'Do thoughts about food, weight or body shape take up a large part of your day?'
    },
    {
      id: 'arfid_1',
      domain: 'arfid_like_avoidance',
      pl: 'Czy unikasz wielu produktów ze względu na teksturę, zapach, smak lub wygląd?',
      en: 'Do you avoid many foods because of texture, smell, taste or appearance?'
    },
    {
      id: 'arfid_2',
      domain: 'arfid_like_avoidance',
      pl: 'Czy często masz bardzo małe zainteresowanie jedzeniem lub szybko tracisz apetyt?',
      en: 'Do you often have very little interest in food or lose appetite quickly?'
    },
    {
      id: 'arfid_3',
      domain: 'arfid_like_avoidance',
      pl: 'Czy unikasz jedzenia z obawy przed zadławieniem, wymiotami, bólem brzucha lub innymi nieprzyjemnymi skutkami?',
      en: 'Do you avoid eating because of fear of choking, vomiting, stomach pain or other unpleasant consequences?'
    },
    {
      id: 'arfid_4',
      domain: 'arfid_like_avoidance',
      pl: 'Czy Twoje ograniczenia jedzeniowe utrudniają jedzenie z innymi, podróże lub codzienne funkcjonowanie?',
      en: 'Do your food limitations make eating with others, travelling or daily functioning difficult?'
    },
    {
      id: 'ortho_1',
      domain: 'orthorexia_like_rigidity',
      pl: 'Czy zdrowe jedzenie stało się źródłem presji, lęku lub poczucia winy?',
      en: 'Has healthy eating become a source of pressure, anxiety or guilt?'
    },
    {
      id: 'ortho_2',
      domain: 'orthorexia_like_rigidity',
      pl: "Czy czujesz się 'zła/y' lub 'słaba/y', gdy zjesz produkt uznany przez Ciebie za niezdrowy?",
      en: "Do you feel 'bad' or 'weak' when you eat something you consider unhealthy?"
    },
    {
      id: 'ortho_3',
      domain: 'orthorexia_like_rigidity',
      pl: 'Czy zasady żywieniowe utrudniają Ci relacje, spontaniczność lub życie społeczne?',
      en: 'Do food rules interfere with your relationships, spontaneity or social life?'
    },
    {
      id: 'ortho_4',
      domain: 'orthorexia_like_rigidity',
      pl: "Czy spędzasz dużo czasu na analizowaniu składu, jakości lub 'czystości' jedzenia?",
      en: "Do you spend a lot of time analysing the ingredients, quality or 'purity' of food?"
    }
  ];

  const redFlags = [
    {
      id: 'red_rapid_weight_loss',
      pl: 'Czy w ostatnich miesiącach nastąpiła szybka, niezamierzona lub niepokojąca utrata masy ciała?',
      en: 'In recent months, have you had rapid, unintended or worrying weight loss?'
    },
    {
      id: 'red_fainting',
      pl: 'Czy zdarzyły Ci się omdlenia, silne zawroty głowy, kołatanie serca lub ból w klatce piersiowej?',
      en: 'Have you experienced fainting, severe dizziness, heart palpitations or chest pain?'
    },
    {
      id: 'red_frequent_vomiting',
      pl: 'Czy często wymiotujesz, celowo lub nie?',
      en: 'Do you vomit frequently, intentionally or unintentionally?'
    },
    {
      id: 'red_laxatives',
      pl: 'Czy regularnie używasz środków przeczyszczających, moczopędnych lub tabletek odchudzających?',
      en: 'Do you regularly use laxatives, diuretics or diet pills?'
    },
    {
      id: 'red_self_harm',
      pl: 'Czy masz myśli o samouszkodzeniu, samobójstwie lub czujesz, że możesz sobie zrobić krzywdę?',
      en: 'Do you have thoughts of self-harm, suicide or feel that you might hurt yourself?'
    },
    {
      id: 'red_medical_condition',
      pl: 'Czy masz chorobę przewlekłą, ciążę lub inne okoliczności medyczne, a jednocześnie mocno ograniczasz jedzenie, wymiotujesz lub objadasz się?',
      en: 'Do you have a chronic illness, pregnancy or other medical circumstances while also strongly restricting, vomiting or binge eating?'
    }
  ].map((item) => ({ ...item, type: 'yesno' }));

  const steps = [
    {
      id: 'restriction',
      questions: questions.filter((question) => question.domain === 'restriction'),
      title: { pl: 'Relacja z jedzeniem i kontrolą', en: 'Relationship with food and control' },
      help: { pl: 'W ciągu ostatnich 3 miesięcy...', en: 'During the last 3 months...' }
    },
    {
      id: 'avoidance',
      questions: questions.filter((question) => question.domain === 'arfid_like_avoidance'),
      title: { pl: 'Ograniczanie i unikanie jedzenia', en: 'Restriction and avoidance' },
      help: { pl: 'Sygnały unikającego lub ograniczającego wzorca jedzenia, bez etykiety diagnostycznej.', en: 'Avoidant or restrictive intake signals, without a diagnostic label.' }
    },
    {
      id: 'binge',
      questions: questions.filter((question) => question.domain === 'binge_loss_control'),
      title: { pl: 'Jedzenie z utratą kontroli', en: 'Loss-of-control eating' },
      help: { pl: 'W ciągu ostatnich 3 miesięcy...', en: 'During the last 3 months...' }
    },
    {
      id: 'compensatory',
      questions: questions.filter((question) => question.domain === 'compensatory_behaviours'),
      title: { pl: 'Zachowania kompensacyjne', en: 'Compensatory behaviours' },
      help: { pl: 'W ciągu ostatnich 3 miesięcy...', en: 'During the last 3 months...' }
    },
    {
      id: 'body',
      questions: questions.filter((question) => question.domain === 'body_image'),
      title: { pl: 'Obraz ciała i zaabsorbowanie', en: 'Body image and preoccupation' },
      help: { pl: 'W ciągu ostatnich 3 miesięcy...', en: 'During the last 3 months...' }
    },
    {
      id: 'orthorexia-like',
      questions: questions.filter((question) => question.domain === 'orthorexia_like_rigidity'),
      title: { pl: "Sztywność wokół 'zdrowego' jedzenia", en: "Rigidity around 'healthy eating'" },
      help: { pl: 'To opisuje wzorce podobne do ortoreksyjnej sztywności, a nie formalną diagnozę.', en: 'This describes orthorexia-like rigidity, not a formal diagnosis.' }
    },
    {
      id: 'safety',
      questions: redFlags,
      title: { pl: 'Zdrowie i sygnały bezpieczeństwa', en: 'Health and safety red flags' },
      help: { pl: 'Te pytania mają odpowiedzi tak/nie i pomagają wskazać, czy warto pilnie porozmawiać ze specjalistą.', en: 'These yes/no questions help indicate whether prompt professional support may be important.' }
    }
  ];

  const copy = {
    pl: {
      step: 'Krok',
      of: 'z',
      next: 'Dalej',
      showResults: 'Pokaż wynik',
      back: 'Wstecz',
      reset: 'Reset',
      required: 'Odpowiedz na wszystkie pytania w tym kroku, zanim przejdziesz dalej.',
      never: 'Nigdy',
      rarely: 'Rzadko',
      sometimes: 'Czasami',
      often: 'Często',
      veryOften: 'Bardzo często',
      yes: 'Tak',
      no: 'Nie',
      results: 'Wynik autotestu',
      signalNote: 'To transparentny wynik edukacyjny, nie skala klinicznej ciężkości.',
      topPatterns: 'Najsilniejsze wzorce',
      noPattern: 'Twoje odpowiedzi nie wskazują na jeden dominujący wzorzec. Jeśli mimo to czujesz niepokój, warto porozmawiać ze specjalistą.',
      whatThisDoesNotMean: 'Czego ten wynik nie oznacza',
      notDiagnosis: 'Ten autotest nie jest diagnozą.',
      noticePatterns: 'Może pomóc zauważyć wzorce w Twojej relacji z jedzeniem.',
      professionalOnly: 'Tylko wykwalifikowany specjalista medyczny lub zdrowia psychicznego może ocenić sytuację, postawić diagnozę i zalecić leczenie.',
      worried: 'Jeśli martwisz się swoim jedzeniem, obrazem ciała, wymiotami, ograniczaniem jedzenia, objadaniem się lub objawami zdrowotnymi, porozmawiaj z lekarzem rodzinnym, psychologiem, psychiatrą, specjalistą leczenia zaburzeń odżywiania lub innym wykwalifikowanym specjalistą.',
      nextSteps: 'Co możesz zrobić dalej',
      nextText: 'Zapisz krótkie podsumowanie, porozmawiaj z zaufaną osobą i rozważ kontakt z lekarzem, psychologiem, psychiatrą lub specjalistą leczenia zaburzeń odżywiania. Bez wstydu, krok po kroku.',
      book: 'Umów konsultację z Natalią',
      message: 'Napisz wiadomość',
      resources: 'Zobacz źródła wsparcia',
      copySummary: 'Skopiuj krótkie podsumowanie wyniku',
      copied: 'Skopiowano krótkie podsumowanie wyniku.',
      copyFailed: 'Nie udało się skopiować automatycznie. Zaznacz i skopiuj podsumowanie ręcznie.',
      score: 'Sygnał',
      low: 'Niski poziom sygnałów',
      moderate: 'Umiarkowany poziom sygnałów',
      elevated: 'Podwyższony poziom sygnałów',
      urgent: 'Warto pilnie porozmawiać ze specjalistą',
      lowText: 'Odpowiedzi pokazują niski poziom sygnałów w tej ankiecie. Jeśli jednak czujesz niepokój lub objawy wpływają na codzienne życie, warto porozmawiać ze specjalistą.',
      moderateText: 'Odpowiedzi pokazują umiarkowany poziom sygnałów. Może to być dobry moment, aby przyjrzeć się wzorcom bez oceniania i rozważyć profesjonalną konsultację.',
      elevatedText: 'Odpowiedzi pokazują podwyższony poziom sygnałów. To nie jest diagnoza, ale warto porozmawiać ze specjalistą, szczególnie jeśli jedzenie, ciało lub kontrola wpływają na zdrowie i codzienność.',
      urgentText: 'Ten wynik wskazuje, że warto jak najszybciej skontaktować się z lekarzem lub specjalistą zdrowia psychicznego. Jeśli jesteś w bezpośrednim niebezpieczeństwie, skontaktuj się z lokalnymi służbami ratunkowymi.',
      restrictionBody: 'Twoje odpowiedzi sugerują, że jedzenie, kontrola i obraz ciała mogą zajmować dużo przestrzeni psychicznej. To nie oznacza diagnozy, ale warto porozmawiać ze specjalistą, szczególnie jeśli ograniczanie jedzenia wpływa na zdrowie, energię, cykl miesiączkowy, relacje lub codzienne funkcjonowanie.',
      bingeOnly: 'Twoje odpowiedzi wskazują na możliwe epizody jedzenia z utratą kontroli. Warto potraktować to bez wstydu i z ciekawością: takie wzorce często łączą się ze stresem, emocjami, restrykcjami lub brakiem regularności.',
      bingeComp: 'Twoje odpowiedzi sugerują cykl objadania i kompensowania. To ważny sygnał, który warto omówić ze specjalistą, szczególnie jeśli pojawiają się wymioty, środki przeczyszczające, głodówki lub nadmierne ćwiczenia.',
      arfid: 'Twoje odpowiedzi sugerują unikający lub bardzo ograniczony wzorzec jedzenia. Może on wynikać z tekstury, zapachu, lęku przed konsekwencjami jedzenia lub niskiego apetytu. Warto omówić to ze specjalistą, szczególnie jeśli wpływa to na zdrowie, energię lub życie społeczne.',
      ortho: "Twoje odpowiedzi sugerują dużą sztywność wokół 'zdrowego' jedzenia. Zdrowe nawyki powinny wspierać życie, a nie je ograniczać. Warto przyjrzeć się, czy zasady żywieniowe nie zwiększają lęku, izolacji lub poczucia winy.",
      genericInsight: 'Najsilniejsze wzorce powyżej pokazują obszary, które mogą być warte spokojnej rozmowy ze specjalistą.',
      summaryIntro: 'Krótkie podsumowanie autotestu relacji z jedzeniem',
      summaryLevel: 'Ogólny poziom sygnałów',
      summaryPatterns: 'Najsilniejsze wzorce',
      noTopPatterns: 'brak dominującego wzorca',
      summaryDisclaimer: 'To nie jest diagnoza.'
    },
    en: {
      step: 'Step',
      of: 'of',
      next: 'Next',
      showResults: 'Show result',
      back: 'Back',
      reset: 'Reset',
      required: 'Answer every question in this step before continuing.',
      never: 'Never',
      rarely: 'Rarely',
      sometimes: 'Sometimes',
      often: 'Often',
      veryOften: 'Very often',
      yes: 'Yes',
      no: 'No',
      results: 'Self-check result',
      signalNote: 'This is a transparent educational result, not a clinical severity scale.',
      topPatterns: 'Strongest patterns',
      noPattern: 'Your answers do not point to one dominant pattern. If you still feel worried, it may be worth speaking with a professional.',
      whatThisDoesNotMean: 'What this result does not mean',
      notDiagnosis: 'This self-check is not a diagnosis.',
      noticePatterns: 'It can help you notice patterns in your relationship with food.',
      professionalOnly: 'Only a qualified medical or mental health professional can assess, diagnose and recommend treatment.',
      worried: 'If you are worried about your eating, body image, purging, restriction, binge eating or health symptoms, please speak with a GP, psychologist, psychiatrist, eating-disorder specialist or other qualified professional.',
      nextSteps: 'What you can do next',
      nextText: 'Save a short summary, speak with someone you trust and consider contacting a GP, psychologist, psychiatrist or eating-disorder specialist. Without shame, one step at a time.',
      book: 'Book a consultation with Natalia',
      message: 'Send a message',
      resources: 'View support resources',
      copySummary: 'Copy a short result summary',
      copied: 'Short result summary copied.',
      copyFailed: 'Automatic copy did not work. Select and copy the summary manually.',
      score: 'Signal',
      low: 'Low signal level',
      moderate: 'Moderate signal level',
      elevated: 'Elevated signal level',
      urgent: 'Prompt professional support recommended',
      lowText: 'Your answers show a low signal level in this self-check. If you still feel worried or symptoms affect daily life, it may be worth speaking with a professional.',
      moderateText: 'Your answers show a moderate signal level. This may be a good moment to look at patterns without judgement and consider professional support.',
      elevatedText: 'Your answers show an elevated signal level. This is not a diagnosis, but it may be worth speaking with a professional, especially if food, body image or control affects your health and daily life.',
      urgentText: 'This result suggests that you should contact a doctor or mental health professional as soon as possible. If you are in immediate danger, contact local emergency services.',
      restrictionBody: 'Your answers suggest that food, control and body image may be taking up a lot of mental space. This is not a diagnosis, but it may be worth speaking with a professional, especially if restriction affects your health, energy, menstrual cycle, relationships or daily functioning.',
      bingeOnly: 'Your answers point to possible episodes of loss-of-control eating. This should be approached without shame and with curiosity: such patterns are often linked with stress, emotions, restriction or lack of regularity.',
      bingeComp: 'Your answers suggest a binge-compensation cycle. This is an important signal to discuss with a professional, especially if vomiting, laxatives, fasting or excessive exercise are involved.',
      arfid: 'Your answers suggest an avoidant or highly limited eating pattern. This may relate to texture, smell, fear of consequences or low appetite. It may be worth discussing with a professional, especially if it affects health, energy or social life.',
      ortho: "Your answers suggest strong rigidity around 'healthy' eating. Healthy habits should support life, not restrict it. It may be worth exploring whether food rules are increasing anxiety, isolation or guilt.",
      genericInsight: 'The strongest patterns above show areas that may be worth discussing calmly with a professional.',
      summaryIntro: 'Short eating pattern self-check summary',
      summaryLevel: 'Overall signal level',
      summaryPatterns: 'Strongest patterns',
      noTopPatterns: 'no dominant pattern',
      summaryDisclaimer: 'This is not a diagnosis.'
    }
  };

  const likertOptions = [
    { value: 0, key: 'never' },
    { value: 1, key: 'rarely' },
    { value: 2, key: 'sometimes' },
    { value: 3, key: 'often' },
    { value: 4, key: 'veryOften' }
  ];

  const yesNoOptions = [
    { value: 'no', key: 'no' },
    { value: 'yes', key: 'yes' }
  ];

  function getLang() {
    return document.documentElement.lang === 'en' ? 'en' : 'pl';
  }

  function text(key) {
    return copy[getLang()][key];
  }

  function localize(item) {
    return item[getLang()];
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function scrollToNode(node) {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    node.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
  }

  function startSelfCheck() {
    els.intro.hidden = true;
    els.results.hidden = true;
    els.wizard.hidden = false;
    currentStep = 0;
    renderStep();
    els.stepTitle.focus?.();
  }

  function resetSelfCheck() {
    Object.keys(answers).forEach((key) => delete answers[key]);
    currentStep = 0;
    els.wizard.hidden = true;
    els.results.hidden = true;
    els.intro.hidden = false;
    els.error.textContent = '';
    scrollToNode(els.intro);
  }

  function renderStep() {
    const step = steps[currentStep];
    const lang = getLang();
    els.stepCount.textContent = `${text('step')} ${currentStep + 1} ${text('of')} ${steps.length}`;
    els.stepTitle.textContent = localize(step.title);
    els.stepTitle.setAttribute('tabindex', '-1');
    els.stepHelp.textContent = localize(step.help);
    els.next.textContent = currentStep === steps.length - 1 ? text('showResults') : text('next');
    els.back.textContent = text('back');
    els.reset.textContent = text('reset');
    els.back.disabled = currentStep === 0;
    els.error.textContent = '';

    const progress = Math.round(((currentStep + 1) / steps.length) * 100);
    els.progress.setAttribute('aria-valuemax', String(steps.length));
    els.progress.setAttribute('aria-valuenow', String(currentStep + 1));
    els.progress.setAttribute('aria-label', lang === 'en' ? els.progress.dataset.progressLabelEn : els.progress.dataset.progressLabelPl);
    els.progressBar.style.width = `${progress}%`;
    els.live.textContent = `${els.stepCount.textContent}: ${els.stepTitle.textContent}`;

    els.questionArea.innerHTML = step.questions.map(renderQuestion).join('');
    els.questionArea.querySelectorAll('input[type="radio"]').forEach((input) => {
      input.addEventListener('change', () => {
        const question = findQuestion(input.name);
        answers[input.name] = question.type === 'yesno' ? input.value : Number(input.value);
        els.error.textContent = '';
      });
    });
  }

  function findQuestion(id) {
    return questions.find((question) => question.id === id) || redFlags.find((question) => question.id === id);
  }

  function renderQuestion(question) {
    const lang = getLang();
    const options = question.type === 'yesno' ? yesNoOptions : likertOptions;
    const gridClass = question.type === 'yesno' ? 'option-grid yes-no' : 'option-grid';
    const legendId = `${question.id}-legend`;
    const optionMarkup = options.map((option) => {
      const inputId = `${question.id}-${option.value}`;
      const checked = Object.prototype.hasOwnProperty.call(answers, question.id) && String(answers[question.id]) === String(option.value) ? ' checked' : '';
      const valueLabel = question.type === 'yesno' ? '' : `<span class="option-value">${option.value}</span>`;
      return `
        <label class="option-card" for="${inputId}">
          <input id="${inputId}" type="radio" name="${question.id}" value="${option.value}" aria-labelledby="${legendId} ${inputId}-label"${checked}>
          ${valueLabel}
          <span class="option-label" id="${inputId}-label">${escapeHtml(copy[lang][option.key])}</span>
        </label>`;
    }).join('');

    return `
      <fieldset class="question-card" data-question-id="${question.id}">
        <legend id="${legendId}">${escapeHtml(question[lang])}</legend>
        <div class="${gridClass}">${optionMarkup}</div>
      </fieldset>`;
  }

  function validateStep() {
    const missing = steps[currentStep].questions.find((question) => !Object.prototype.hasOwnProperty.call(answers, question.id));
    if (!missing) return true;

    els.error.textContent = text('required');
    const firstInput = els.questionArea.querySelector(`[name="${missing.id}"]`);
    if (firstInput) firstInput.focus();
    return false;
  }

  function nextStep() {
    if (!validateStep()) return;
    if (currentStep === steps.length - 1) {
      showResults();
      return;
    }
    currentStep += 1;
    renderStep();
    els.stepTitle.focus();
  }

  function previousStep() {
    if (currentStep === 0) return;
    currentStep -= 1;
    renderStep();
    els.stepTitle.focus();
  }

  function calculateResult() {
    const domainStats = Object.keys(domains).reduce((stats, domain) => {
      stats[domain] = { sum: 0, count: 0, average: 0 };
      return stats;
    }, {});

    let totalScore = 0;
    questions.forEach((question) => {
      const value = Number(answers[question.id] || 0);
      totalScore += value;
      domainStats[question.domain].sum += value;
      domainStats[question.domain].count += 1;
    });

    Object.values(domainStats).forEach((stat) => {
      stat.average = stat.count ? stat.sum / stat.count : 0;
    });

    const maxScore = questions.length * 4;
    const normalizedScore = maxScore ? totalScore / maxScore : 0;
    const urgentFlags = redFlags.filter((flag) => answers[flag.id] === 'yes');
    const domainAverages = Object.values(domainStats).map((stat) => stat.average);

    let level = 'low';
    if (urgentFlags.length > 0) {
      level = 'urgent';
    } else if (normalizedScore >= 0.45 || domainAverages.some((average) => average >= 3)) {
      level = 'elevated';
    } else if (normalizedScore >= 0.25 || domainAverages.some((average) => average >= 2.25)) {
      level = 'moderate';
    }

    const topPatterns = Object.entries(domainStats)
      .map(([domain, stat]) => ({ domain, ...stat }))
      .filter((stat) => stat.average > 0)
      .sort((a, b) => b.average - a.average)
      .slice(0, 3);

    return { domainStats, totalScore, maxScore, normalizedScore, urgentFlags, level, topPatterns };
  }

  function showResults() {
    els.wizard.hidden = true;
    els.results.hidden = false;
    renderResults(true);
  }

  function renderResults(shouldFocus = false) {
    const lang = getLang();
    const result = calculateResult();
    const levelClass = result.level === 'urgent' ? 'signal-urgent' : result.level === 'elevated' ? 'signal-elevated' : '';
    const insights = resultInsights(result);
    const levelText = copy[lang][result.level];
    const scorePercent = Math.round(result.normalizedScore * 100);

    const patternMarkup = result.topPatterns.length
      ? result.topPatterns.map((pattern) => {
        const width = Math.round((pattern.average / 4) * 100);
        const label = domains[pattern.domain][lang];
        return `
          <article class="pattern-card">
            <h3>${escapeHtml(label)}</h3>
            <div class="pattern-score">
              <span>${escapeHtml(text('score'))}: ${pattern.average.toFixed(1)} / 4</span>
              <span class="pattern-meter" aria-hidden="true"><span style="width: ${width}%"></span></span>
            </div>
          </article>`;
      }).join('')
      : `<article class="pattern-card"><p>${escapeHtml(text('noPattern'))}</p></article>`;

    els.results.innerHTML = `
      <div class="stack">
        <span class="eyebrow">${escapeHtml(text('results'))}</span>
        <h2>${escapeHtml(levelText)}</h2>
        <p>${escapeHtml(copy[lang][`${result.level}Text`])}</p>
      </div>
      <div class="result-grid">
        <article class="result-card">
          <span class="signal-badge ${levelClass}">${escapeHtml(levelText)}</span>
          <h3>${escapeHtml(text('results'))}</h3>
          <p>${escapeHtml(text('signalNote'))} ${escapeHtml(text('score'))}: ${scorePercent}%.</p>
          ${insights.map((insight) => `<p>${escapeHtml(insight)}</p>`).join('')}
          <div class="result-actions">
            <a class="btn btn-primary" href="index.html#booking">${escapeHtml(text('book'))}</a>
            <a class="btn btn-secondary" href="${emailHref()}">${escapeHtml(text('message'))}</a>
            <a class="btn btn-secondary" href="#support-resources">${escapeHtml(text('resources'))}</a>
            <button class="btn btn-secondary" type="button" data-copy-summary>${escapeHtml(text('copySummary'))}</button>
            <button class="btn btn-secondary" type="button" data-result-reset>${escapeHtml(text('reset'))}</button>
          </div>
          <p class="copy-status" data-copy-status aria-live="polite"></p>
        </article>
        <div class="pattern-list">
          <article class="meaning-card">
            <h3>${escapeHtml(text('whatThisDoesNotMean'))}</h3>
            <p>${escapeHtml(text('notDiagnosis'))}</p>
            <p>${escapeHtml(text('noticePatterns'))}</p>
            <p>${escapeHtml(text('professionalOnly'))}</p>
            <p>${escapeHtml(text('worried'))}</p>
          </article>
          <article class="next-card">
            <h3>${escapeHtml(text('nextSteps'))}</h3>
            <p>${escapeHtml(text('nextText'))}</p>
          </article>
          <div>
            <h3>${escapeHtml(text('topPatterns'))}</h3>
            <div class="pattern-list">${patternMarkup}</div>
          </div>
        </div>
      </div>`;

    if (shouldFocus) {
      els.results.focus();
      scrollToNode(els.results);
    }
  }

  function resultInsights(result) {
    const stats = result.domainStats;
    const high = (domain) => stats[domain].average >= 2.25;
    const insights = [];

    if (result.level === 'urgent') {
      insights.push(text('urgentText'));
    }
    if (high('restriction') && high('body_image')) {
      insights.push(text('restrictionBody'));
    }
    if (high('binge_loss_control') && high('compensatory_behaviours')) {
      insights.push(text('bingeComp'));
    } else if (high('binge_loss_control')) {
      insights.push(text('bingeOnly'));
    }
    if (high('arfid_like_avoidance')) {
      insights.push(text('arfid'));
    }
    if (high('orthorexia_like_rigidity')) {
      insights.push(text('ortho'));
    }
    if (!insights.length && result.level !== 'low') {
      insights.push(text('genericInsight'));
    }
    return insights.slice(0, 4);
  }

  function emailHref() {
    const subject = getLang() === 'en'
      ? 'I would like to talk about my relationship with food'
      : 'Chciał(a)bym porozmawiać o mojej relacji z jedzeniem';
    return `mailto:${email}?subject=${encodeURIComponent(subject)}`;
  }

  function resultSummary() {
    const result = calculateResult();
    const lang = getLang();
    const patterns = result.topPatterns.length
      ? result.topPatterns.map((pattern) => domains[pattern.domain][lang]).join(', ')
      : text('noTopPatterns');

    return [
      text('summaryIntro'),
      `${text('summaryLevel')}: ${copy[lang][result.level]}`,
      `${text('summaryPatterns')}: ${patterns}`,
      text('summaryDisclaimer')
    ].join('\n');
  }

  async function copySummary() {
    const status = els.results.querySelector('[data-copy-status]');
    const summary = resultSummary();
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(summary);
      } else {
        fallbackCopy(summary);
      }
      if (status) status.textContent = text('copied');
    } catch (error) {
      fallbackCopy(summary);
      if (status) status.textContent = text('copyFailed');
    }
  }

  function fallbackCopy(value) {
    const textarea = document.createElement('textarea');
    textarea.value = value;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.append(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
  }

  els.start.addEventListener('click', startSelfCheck);
  els.reset.addEventListener('click', resetSelfCheck);
  els.back.addEventListener('click', previousStep);
  els.next.addEventListener('click', nextStep);
  els.results.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.matches('[data-copy-summary]')) copySummary();
    if (button.matches('[data-result-reset]')) resetSelfCheck();
  });

  const observer = new MutationObserver(() => {
    if (!els.wizard.hidden) renderStep();
    if (!els.results.hidden) renderResults(false);
  });
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
})();
